"use client";

import { PINJAMAN_PRODUCTS } from "@/lib/constants";
import { Sparkles } from "lucide-react";
import Link from "next/link";

export default function PinjamanTable() {
  return (
    <div className="overflow-x-auto rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 shadow-lg">
      <table className="w-full text-left text-sm">
        <thead className="bg-slate-100 dark:bg-slate-900/80 text-xs uppercase tracking-wider text-black dark:text-slate-300 font-bold border-b border-slate-200 dark:border-slate-700">
          <tr>
            <th scope="col" className="px-6 py-4">Jenis Pinjaman</th>
            <th scope="col" className="px-6 py-4">Plafon Pembiayaan</th>
            <th scope="col" className="px-6 py-4">Suku Bunga (Flat)</th>
            <th scope="col" className="px-6 py-4">Jangka Waktu (Tenor)</th>
            <th scope="col" className="px-6 py-4 text-center">Aksi</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-100 dark:divide-slate-700/60">
          {PINJAMAN_PRODUCTS.map((item, idx) => (
            <tr
              key={idx}
              className={`transition-colors hover:bg-slate-50 dark:hover:bg-slate-700/40 ${
                item.highlight
                  ? "bg-cyan-50/50 dark:bg-cyan-950/20 font-medium"
                  : ""
              }`}
            >
              <td className="px-6 py-4">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-black dark:text-white">
                    {item.jenis}
                  </span>
                  {item.highlight && (
                    <span className="inline-flex items-center gap-1 text-[10px] font-extrabold bg-cyan-600 text-white px-2 py-0.5 rounded-full shadow-sm">
                      <Sparkles className="w-3 h-3" /> Rekomendasi
                    </span>
                  )}
                </div>
              </td>
              <td className="px-6 py-4 font-mono font-semibold text-black dark:text-slate-300">
                {item.plafon}
              </td>
              <td className="px-6 py-4">
                <span className="inline-block px-2.5 py-1 rounded-lg bg-teal-50 dark:bg-teal-950/60 text-teal-700 dark:text-teal-300 font-bold text-xs">
                  {item.bunga}
                </span>
              </td>
              <td className="px-6 py-4 font-medium text-black dark:text-slate-300">
                {item.tenor}
              </td>
              <td className="px-6 py-4 text-center">
                <Link
                  href="/simulasi#pinjaman"
                  className="inline-flex items-center justify-center px-3 py-1.5 text-xs font-bold text-cyan-700 dark:text-cyan-300 bg-cyan-50 dark:bg-cyan-950/60 hover:bg-cyan-600 hover:text-white rounded-lg transition-colors border border-cyan-200 dark:border-cyan-800"
                >
                  Hitung Angsuran
                </Link>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
