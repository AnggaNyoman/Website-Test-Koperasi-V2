"use client";

import { useState, useEffect } from "react";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from "recharts";
import { SHU_DATA } from "@/lib/constants";
import { formatRupiah } from "@/lib/utils";
import { PiggyBank, Receipt, Building2, TrendingUp, HelpCircle } from "lucide-react";
export default function SHUChart() {
  const [mounted, setMounted] = useState(false);
  const [simpananAnggota, setSimpananAnggota] = useState<number>(10000000);
  const [transaksiAnggota, setTransaksiAnggota] = useState<number>(5000000);

  useEffect(() => {
    setMounted(true);
  }, []);

  const chartData = [
    { name: "Berdasarkan Simpanan (40%)", value: 40, color: "#065A74", icon: PiggyBank, desc: "Dibagikan proporsional sesuai saldo simpanan pokok, wajib, dan sukarela anggota" },
    { name: "Berdasarkan Transaksi (40%)", value: 40, color: "#0ABCF0", icon: Receipt, desc: "Dibagikan sesuai volume transaksi pinjaman dan aktivitas simpan pinjam anggota" },
    { name: "Dana Cadangan Koperasi (20%)", value: 20, color: "#D4AF37", icon: Building2, desc: "Dialokasikan untuk memperkuat modal dan pengembangan fasilitas koperasi" },
  ];

  // Estimated SHU simulation based on 8% rate
  // Estimasi SHU Simpanan = Simpanan * 8% * 0.4
  // Estimasi SHU Transaksi = Transaksi * 8% * 0.4
  const estimasiShuSimpanan = Math.round(simpananAnggota * 0.08 * 0.4);
  const estimasiShuTransaksi = Math.round(transaksiAnggota * 0.08 * 0.4);
  const totalEstimasiShu = estimasiShuSimpanan + estimasiShuTransaksi;

  return (
    <div className="space-y-12">
      {/* Visual Chart & Percentage Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
        {/* Recharts Pie Chart */}
        <div className="lg:col-span-6 bg-white dark:bg-slate-800 p-6 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-lg">
          <div className="text-center mb-4">
            <span className="text-xs uppercase font-bold tracking-wider text-black">
              Komposisi Pembagian
            </span>
            <h3 className="text-xl font-bold text-black dark:text-white">
              Alokasi Sisa Hasil Usaha (SHU)
            </h3>
          </div>

          <div className="h-[280px] w-full">
            {mounted ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={chartData}
                    cx="50%"
                    cy="50%"
                    innerRadius={65}
                    outerRadius={95}
                    paddingAngle={4}
                    dataKey="value"
                  >
                    {chartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} stroke="none" />
                    ))}
                  </Pie>
                  <Tooltip
                    formatter={(value: any) => [`${value}%`, "Porsi Alokasi"]}
                    contentStyle={{
                      backgroundColor: "#1e293b",
                      border: "none",
                      borderRadius: "12px",
                      color: "#fff",
                      fontSize: "12px",
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-full flex items-center justify-center text-black text-xs">
                Memuat grafik...
              </div>
            )}
          </div>

          <div className="grid grid-cols-3 gap-2 pt-4 border-t border-slate-100 dark:border-slate-700 text-center">
            <div>
              <div className="text-xs font-bold text-teal-700 dark:text-teal-400">40%</div>
              <div className="text-[10px] text-black">Jasa Simpanan</div>
            </div>
            <div>
              <div className="text-xs font-bold text-cyan-600 dark:text-cyan-400">40%</div>
              <div className="text-[10px] text-black">Jasa Transaksi</div>
            </div>
            <div>
              <div className="text-xs font-bold text-amber-500">20%</div>
              <div className="text-[10px] text-black">Cadangan KSP</div>
            </div>
          </div>
        </div>

        {/* Distribution Details Breakdown */}
        <div className="lg:col-span-6 space-y-4">
          {chartData.map((item, idx) => {
            const Icon = item.icon;
            return (
              <div
                key={idx}
                className="bg-white dark:bg-slate-800 rounded-2xl p-5 border border-slate-200 dark:border-slate-700 shadow-sm flex items-start gap-4"
              >
                <div
                  className="w-12 h-12 rounded-xl flex items-center justify-center shrink-0 text-white font-bold text-sm shadow"
                  style={{ backgroundColor: item.color }}
                >
                  <Icon className="w-6 h-6" />
                </div>
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <h4 className="font-bold text-black dark:text-white text-base">
                      {item.name}
                    </h4>
                  </div>
                  <p className="text-xs text-black dark:text-slate-300 leading-relaxed">
                    {item.desc}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* SHU Simulation Calculator */}
      <div className="bg-slate-50 dark:bg-slate-800/80 rounded-2xl p-6 sm:p-8 border border-slate-200 dark:border-slate-700">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-teal-500/20 text-teal-600 dark:text-teal-400 flex items-center justify-center">
            <TrendingUp className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-xl font-bold text-black dark:text-white">
              Simulasi Estimasi Penerimaan SHU Anda
            </h3>
            <p className="text-xs text-black dark:text-slate-400">
              Berdasarkan imbal hasil rata-rata 8% per tahun buku koperasi
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-black dark:text-slate-400 mb-2">
              Perkiraan Total Saldo Simpanan Anda
            </label>
            <div className="font-mono text-lg font-bold text-teal-600 dark:text-teal-400 mb-2">
              {formatRupiah(simpananAnggota)}
            </div>
            <input
              type="range"
              min={500000}
              max={100000000}
              step={500000}
              value={simpananAnggota}
              onChange={(e) => setSimpananAnggota(Number(e.target.value))}
              className="w-full accent-teal-600 h-2 bg-slate-200 dark:bg-slate-700 rounded-lg cursor-pointer"
            />
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-black dark:text-slate-400 mb-2">
              Perkiraan Total Transaksi Pinjaman Anda (1 Tahun)
            </label>
            <div className="font-mono text-lg font-bold text-cyan-600 dark:text-cyan-400 mb-2">
              {formatRupiah(transaksiAnggota)}
            </div>
            <input
              type="range"
              min={0}
              max={50000000}
              step={500000}
              value={transaksiAnggota}
              onChange={(e) => setTransaksiAnggota(Number(e.target.value))}
              className="w-full accent-cyan-600 h-2 bg-slate-200 dark:bg-slate-700 rounded-lg cursor-pointer"
            />
          </div>
        </div>

        {/* Results Banner */}
        <div className="bg-white dark:bg-slate-900 rounded-xl p-6 border border-teal-200 dark:border-teal-800/60 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-black">
              Estimasi SHU Diterima ( RAT Januari )
            </span>
            <div className="text-3xl font-extrabold text-teal-600 dark:text-teal-400 font-mono mt-1">
              {formatRupiah(totalEstimasiShu)}
            </div>
            <div className="text-xs text-black mt-1">
              SHU Simpanan: <span className="font-mono font-semibold">{formatRupiah(estimasiShuSimpanan)}</span> + SHU Transaksi: <span className="font-mono font-semibold">{formatRupiah(estimasiShuTransaksi)}</span>
            </div>
          </div>

          <div className="flex items-center gap-2 text-xs text-black max-w-xs bg-slate-50 dark:bg-slate-800 p-3 rounded-xl">
            <HelpCircle className="w-4 h-4 text-teal-600 shrink-0" />
            <span>Besaran pasti disahkan pada Rapat Anggota Tahunan (RAT) berdasarkan kinerja keuangan riil koperasi.</span>
          </div>
        </div>
      </div>
    </div>
  );
}
