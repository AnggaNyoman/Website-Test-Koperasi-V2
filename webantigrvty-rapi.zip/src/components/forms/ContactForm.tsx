"use client";

import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { toast } from "sonner";
import { SITE_CONFIG } from "@/lib/constants";
import { Send, CheckCircle2, Loader2, MessageSquare } from "lucide-react";
const contactSchema = z.object({
  name: z.string().min(2, "Nama minimal 2 karakter"),
  email: z.string().email("Format email tidak valid"),
  phone: z
    .string()
    .min(10, "Nomor telepon minimal 10 digit")
    .regex(/^(?:\+62|62|0)8[1-9][0-9]{6,10}$/, "Format nomor HP tidak valid (contoh: 081234567890)"),
  subject: z.string().min(3, "Subjek pesan minimal 3 karakter"),
  message: z.string().min(10, "Pesan minimal 10 karakter"),
});

type ContactFormData = z.infer<typeof contactSchema>;

export default function ContactForm() {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<ContactFormData>({
    resolver: zodResolver(contactSchema),
  });

  const onSubmit = async (data: ContactFormData) => {
    setIsSubmitting(true);
    try {
      // Simulate API call & save to localStorage
      const existing = JSON.parse(localStorage.getItem("contact_messages") || "[]");
      existing.push({ ...data, createdAt: new Date().toISOString() });
      localStorage.setItem("contact_messages", JSON.stringify(existing));

      // Construct WhatsApp message URL
      const text = `Halo Admin Koperasi Mandara Sedana Kuta,\n\nNama: ${data.name}\nEmail: ${data.email}\nNo. HP: ${data.phone}\nSubjek: ${data.subject}\n\nPesan:\n${data.message}`;
      const waUrl = `https://wa.me/${SITE_CONFIG.whatsapp}?text=${encodeURIComponent(text)}`;

      toast.success("Pesan Berhasil Terkirim!", {
        description: "Terima kasih! Kami akan segera menghubungi Anda kembali.",
      });

      setIsSuccess(true);
      reset();

      // Open WA in a new window/tab after a short pause
      setTimeout(() => {
        window.open(waUrl, "_blank");
      }, 1200);
    } catch {
      toast.error("Gagal mengirim pesan", {
        description: "Silakan coba lagi atau hubungi langsung via WhatsApp.",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="bg-white dark:bg-slate-800 rounded-3xl p-6 sm:p-10 border border-slate-200 dark:border-slate-700 shadow-xl">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-xl bg-teal-50 dark:bg-teal-950/60 text-teal-600 dark:text-teal-400 flex items-center justify-center">
          <MessageSquare className="w-5 h-5" />
        </div>
        <div>
          <h3 className="text-xl font-bold text-black dark:text-white">
            Kirim Pesan ke Manajemen
          </h3>
          <p className="text-xs text-black dark:text-slate-400">
            Kami akan merespons dalam waktu 1x24 jam kerja
          </p>
        </div>
      </div>

      {isSuccess ? (
        <div className="text-center py-10">
          <div className="w-16 h-16 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mx-auto mb-4">
            <CheckCircle2 className="w-8 h-8" />
          </div>
          <h4 className="text-xl font-bold text-black dark:text-white mb-2">
            Pesan Terkirim!
          </h4>
          <p className="text-sm text-black dark:text-slate-300 max-w-md mx-auto mb-6">
            Pesan Anda telah berhasil tercatat. Tim Customer Service kami akan segera menindaklanjuti pertanyaan atau permohonan Anda.
          </p>
          <button
            type="button"
            onClick={() => setIsSuccess(false)}
            className="px-6 py-2.5 bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs rounded-xl transition-colors"
          >
            Kirim Pesan Lainnya
          </button>
        </div>
      ) : (
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-black dark:text-slate-400 mb-1.5">
                Nama Lengkap <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                placeholder="I Wayan..."
                {...register("name")}
                className={`w-full px-4 py-3 rounded-xl bg-slate-50 dark:bg-slate-900/60 border text-sm text-black dark:text-white focus:outline-none focus:ring-2 focus:ring-teal-500 transition-colors ${
                  errors.name
                    ? "border-red-500 dark:border-red-500"
                    : "border-slate-200 dark:border-slate-700"
                }`}
              />
              {errors.name && (
                <p className="text-red-500 text-[11px] mt-1 font-medium">{errors.name.message}</p>
              )}
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-black dark:text-slate-400 mb-1.5">
                Alamat Email <span className="text-red-500">*</span>
              </label>
              <input
                type="email"
                placeholder="nama@email.com"
                {...register("email")}
                className={`w-full px-4 py-3 rounded-xl bg-slate-50 dark:bg-slate-900/60 border text-sm text-black dark:text-white focus:outline-none focus:ring-2 focus:ring-teal-500 transition-colors ${
                  errors.email
                    ? "border-red-500 dark:border-red-500"
                    : "border-slate-200 dark:border-slate-700"
                }`}
              />
              {errors.email && (
                <p className="text-red-500 text-[11px] mt-1 font-medium">{errors.email.message}</p>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-black dark:text-slate-400 mb-1.5">
                Nomor Handphone / WhatsApp <span className="text-red-500">*</span>
              </label>
              <input
                type="tel"
                placeholder="081234567890"
                {...register("phone")}
                className={`w-full px-4 py-3 rounded-xl bg-slate-50 dark:bg-slate-900/60 border text-sm text-black dark:text-white focus:outline-none focus:ring-2 focus:ring-teal-500 transition-colors ${
                  errors.phone
                    ? "border-red-500 dark:border-red-500"
                    : "border-slate-200 dark:border-slate-700"
                }`}
              />
              {errors.phone && (
                <p className="text-red-500 text-[11px] mt-1 font-medium">{errors.phone.message}</p>
              )}
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-black dark:text-slate-400 mb-1.5">
                Subjek Pesan <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                placeholder="Informasi Pinjaman / Simpanan..."
                {...register("subject")}
                className={`w-full px-4 py-3 rounded-xl bg-slate-50 dark:bg-slate-900/60 border text-sm text-black dark:text-white focus:outline-none focus:ring-2 focus:ring-teal-500 transition-colors ${
                  errors.subject
                    ? "border-red-500 dark:border-red-500"
                    : "border-slate-200 dark:border-slate-700"
                }`}
              />
              {errors.subject && (
                <p className="text-red-500 text-[11px] mt-1 font-medium">{errors.subject.message}</p>
              )}
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-black dark:text-slate-400 mb-1.5">
              Isi Pesan <span className="text-red-500">*</span>
            </label>
            <textarea
              rows={4}
              placeholder="Tuliskan pertanyaan atau kebutuhan Anda secara jelas..."
              {...register("message")}
              className={`w-full px-4 py-3 rounded-xl bg-slate-50 dark:bg-slate-900/60 border text-sm text-black dark:text-white focus:outline-none focus:ring-2 focus:ring-teal-500 transition-colors ${
                errors.message
                  ? "border-red-500 dark:border-red-500"
                  : "border-slate-200 dark:border-slate-700"
              }`}
            />
            {errors.message && (
              <p className="text-red-500 text-[11px] mt-1 font-medium">{errors.message.message}</p>
            )}
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-teal-600 to-cyan-600 hover:from-teal-700 hover:to-cyan-700 text-white font-bold py-3.5 px-6 rounded-xl shadow-lg transition-all disabled:opacity-50 text-sm"
          >
            {isSubmitting ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Mengirim Pesan...</span>
              </>
            ) : (
              <>
                <Send className="w-4 h-4" />
                <span>Kirim Pesan Sekarang</span>
              </>
            )}
          </button>
        </form>
      )}
    </div>
  );
}
