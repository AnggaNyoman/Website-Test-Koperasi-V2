"use client";

import { useState, useRef } from "react";
import Image from "next/image";
import { motion, useInView, AnimatePresence } from "framer-motion";
import { Users, Maximize2, X, ShieldCheck, Briefcase, ChevronDown } from "lucide-react";

interface DivisionCardProps {
  title: string;
  lead: string;
  staff: string[];
  color: string;
}

function DivisionCard({ title, lead, staff, color }: DivisionCardProps) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="bg-white dark:bg-slate-800 rounded-xl border border-slate-200 dark:border-slate-700 shadow-sm overflow-hidden transition-all duration-200 hover:shadow-md">
      <div className={`h-1.5 w-full ${color}`} />
      <div className="p-4">
        <span className="text-[10px] uppercase tracking-wider font-bold text-black dark:text-slate-500">
          Divisi / Bagian
        </span>
        <h4 className="font-bold text-sm sm:text-base text-black dark:text-white mb-1">
          {title}
        </h4>
        <div className="inline-block bg-teal-50 dark:bg-teal-950/50 text-teal-700 dark:text-teal-300 text-xs px-2 py-0.5 rounded font-semibold mb-2">
          {lead}
        </div>

        {staff.length > 0 ? (
          <>
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="w-full flex items-center justify-between text-xs font-medium text-black dark:text-slate-400 hover:text-teal-600 dark:hover:text-teal-400 pt-2 border-t border-slate-100 dark:border-slate-700/60"
            >
              <span>{staff.length} Unit / Staf Terkait</span>
              <ChevronDown className={`w-3.5 h-3.5 transform transition-transform ${isOpen ? "rotate-180" : ""}`} />
            </button>

            {isOpen && (
              <ul className="mt-2 space-y-1 text-xs text-black dark:text-slate-300 bg-slate-50 dark:bg-slate-900/40 p-2.5 rounded-lg border border-slate-100 dark:border-slate-800">
                {staff.map((s, i) => (
                  <li key={i} className="flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-teal-500" />
                    {s}
                  </li>
                ))}
              </ul>
            )}
          </>
        ) : (
          <p className="text-xs text-black dark:text-slate-500 pt-2 border-t border-slate-100 dark:border-slate-700/60">
            Setara Kepala Bagian
          </p>
        )}
      </div>
    </div>
  );
}

export default function StrukturOrganisasi() {
  const [isLightboxOpen, setIsLightboxOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const divisions = [
    {
      title: "SDM, Umum & Kesekretariatan",
      lead: "Kepala Bagian SDM",
      staff: ["SDM & Humas", "Kesekretariatan & Umum", "Cleaning Service"],
      color: "bg-emerald-500",
    },
    {
      title: "Dana & Pelayanan",
      lead: "Kepala Bagian Dana",
      staff: ["Supervisor", "Teller & PDL", "Member Care & Service", "Member Prioritas & Kerja Sama Sekolah"],
      color: "bg-teal-500",
    },
    {
      title: "Keuangan",
      lead: "Kepala Bagian Keuangan",
      staff: ["Keuangan & Pelaporan"],
      color: "bg-cyan-500",
    },
    {
      title: "Pinjaman",
      lead: "Kepala Bagian Pinjaman",
      staff: ["Account Officer", "Admin Pinjaman", "Penanganan Pinjaman Bermasalah"],
      color: "bg-blue-500",
    },
    {
      title: "TI, R&D & Promosi",
      lead: "Kepala Bagian TI",
      staff: ["TI & RND", "Tim Markom"],
      color: "bg-indigo-500",
    },
    {
      title: "Kantor Cabang Sesetan",
      lead: "Kepala Cabang",
      staff: ["Teller / MCS", "PDL"],
      color: "bg-amber-500",
    },
    {
      title: "Bisnis & Treasury",
      lead: "Kepala Bagian Bisnis",
      staff: [],
      color: "bg-purple-500",
    },
  ];

  return (
    <section id="struktur" ref={ref} className="section-py bg-white dark:bg-slate-900 relative">
      <div className="section-container">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12 md:mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-teal-50 dark:bg-teal-950/60 border border-teal-200 dark:border-teal-800 text-teal-700 dark:text-teal-300 text-sm font-semibold mb-4">
            <Users className="w-4 h-4 text-teal-600" />
            <span>Tata Kelola Profesional</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-black dark:text-white tracking-tight mb-4">
            Struktur Organisasi & Manajemen
          </h2>
          <p className="text-black dark:text-slate-300 text-base sm:text-lg">
            Dikelola oleh pengurus dan manajemen operasional yang berpengalaman, akuntabel, dan berdedikasi tinggi untuk kemajuan bersama.
          </p>
        </div>

        {/* Top Management High-Level Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          {/* Pengawas */}
          <div className="p-6 rounded-2xl bg-gradient-to-br from-slate-900 to-slate-800 text-white shadow-xl relative overflow-hidden border border-slate-700">
<div className="w-10 h-10 rounded-xl bg-teal-500/20 flex items-center justify-center text-teal-400 mb-4">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <span className="text-xs uppercase tracking-wider text-teal-300 font-bold">Fungsi Pengawasan</span>
            <h3 className="text-xl font-bold mt-1 mb-2">Dewan Pengawas</h3>
            <p className="text-slate-300 text-xs sm:text-sm">
              Mengawasi tata kelola, kepatuhan hukum, dan kinerja operasional koperasi secara berkala dibantu Satuan Pengawas Internal (SPI).
            </p>
          </div>

          {/* Manajer Utama */}
          <div className="p-6 rounded-2xl bg-gradient-to-br from-teal-800 via-teal-900 to-slate-900 text-white shadow-xl relative overflow-hidden border border-teal-600/40">
<div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center text-gold mb-4">
              <Briefcase className="w-5 h-5" />
            </div>
            <span className="text-xs uppercase tracking-wider text-teal-200 font-bold">Pimpinan Eksekutif</span>
            <h3 className="text-xl font-bold mt-1 mb-2">Manajer Utama</h3>
            <p className="text-teal-100 text-xs sm:text-sm">
              Memimpin perumusan strategi dan pelaksanaan seluruh kegiatan usaha demi tercapainya visi dan misi koperasi.
            </p>
          </div>

          {/* Dual Manajer Operasional & Bisnis */}
          <div className="p-6 rounded-2xl bg-gradient-to-br from-slate-900 to-slate-800 text-white shadow-xl relative overflow-hidden border border-slate-700">
<div className="w-10 h-10 rounded-xl bg-cyan-500/20 flex items-center justify-center text-cyan-400 mb-4">
              <Users className="w-5 h-5" />
            </div>
            <span className="text-xs uppercase tracking-wider text-cyan-300 font-bold">Direksi Bidang</span>
            <h3 className="text-xl font-bold mt-1 mb-2">Manajer Ops & Bisnis</h3>
            <p className="text-slate-300 text-xs sm:text-sm">
              Membawahi operasional harian, kepatuhan, pelayanan anggota serta ekspansi bisnis & teknologi Madata Mobile.
            </p>
          </div>
        </div>

        {/* Diagram Image Presentation with Lightbox Trigger */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{ duration: 0.6 }}
          className="mb-14"
        >
          <div className="relative group">
            <div
              className="relative w-full cursor-pointer rounded-2xl border border-teal-200/60 dark:border-teal-700/40 overflow-hidden bg-white"
              onClick={() => setIsLightboxOpen(true)}
            >
              <Image
                src="/struktur-organisasi.png"
                alt="Bagan Struktur Manajemen Koperasi Mandara Sedana Kuta"
                width={2000}
                height={887}
                className="w-full h-auto group-hover:scale-[1.02] transition-transform duration-500"
                sizes="(max-width: 1280px) 100vw, 1200px"
              />
              <div className="absolute inset-0 bg-slate-900/0 group-hover:bg-slate-900/30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <span className="bg-white/95 dark:bg-slate-900/95 text-black dark:text-white text-sm font-semibold px-4 py-2 rounded-full flex items-center gap-2 shadow-lg">
                  <Maximize2 className="w-4 h-4 text-teal-600" /> Klik untuk Memperbesar Bagan
                </span>
              </div>
            </div>

            {/* Caption — centered, directly below the full (uncropped, unobscured) photo */}
            <p className="mt-3 text-center text-black dark:text-slate-300 text-xs sm:text-sm font-semibold">
              Bagan Resmi Manajemen Operasional Koperasi Mandara Sedana Kuta
            </p>

            <div className="mt-1 flex justify-center">
              <button
                onClick={() => setIsLightboxOpen(true)}
                className="text-teal-600 dark:text-teal-400 font-semibold hover:underline flex items-center gap-1 text-xs"
              >
                <Maximize2 className="w-3.5 h-3.5" /> Tampilkan Layar Penuh
              </button>
            </div>
          </div>
        </motion.div>

        {/* Detailed Divisions Grid */}
        <div className="mb-8">
          <h3 className="text-xl font-bold text-black dark:text-white mb-6 text-center">
            Rincian Divisi Operasional & Pelayanan
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {divisions.map((div, i) => (
              <DivisionCard key={i} {...div} />
            ))}
          </div>
        </div>
      </div>

      {/* Lightbox Modal */}
      <AnimatePresence>
        {isLightboxOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/95 flex items-center justify-center p-4"
            onClick={() => setIsLightboxOpen(false)}
          >
            <button
              onClick={() => setIsLightboxOpen(false)}
              className="absolute top-6 right-6 text-white hover:text-slate-300 p-2.5 rounded-full bg-white/10 hover:bg-white/20 transition-colors z-50"
              aria-label="Tutup"
            >
              <X className="w-6 h-6" />
            </button>
            <div
              className="relative max-w-6xl max-h-[90vh] w-full h-[80vh] bg-white rounded-xl overflow-hidden p-4"
              onClick={(e) => e.stopPropagation()}
            >
              <Image
                src="/struktur-organisasi.png"
                alt="Bagan Struktur Organisasi Full"
                fill
                className="object-contain"
                sizes="100vw"
              />
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
