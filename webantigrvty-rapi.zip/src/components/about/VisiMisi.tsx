"use client";

import { useRef, useState } from "react";
import Image from "next/image";
import { motion, useInView } from "framer-motion";
import { Eye, Target, X } from "lucide-react";

// ============================================
// VISI & MISI SECTION
// ============================================

const misi = [
  "Meningkatkan kualitas layanan koperasi melalui digitalisasi dan inovasi berkelanjutan.",
  "Memperluas jaringan kemitraan, pengembangan unit usaha dan pembukaan cabang untuk menjangkau lebih banyak anggota.",
  "Mendukung pertumbuhan usaha anggota melalui pembinaan, pembiayaan, dan promosi bersama.",
  "Membangun ekosistem koperasi yang terintegrasi dan memberdayakan potensi ekonomi anggota.",
  "Menerapkan tata kelola koperasi yang profesional, transparan, dan berorientasi pada keberlanjutan.",
];

export default function VisiMisi() {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, margin: "-80px" });
  const [lightbox, setLightbox] = useState(false);

  return (
    <section
      ref={ref}
      id="visi-misi"
      className="section-py bg-slate-50 dark:bg-slate-900 relative overflow-hidden"
    >
<div className="section-container">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          className="text-center mb-12 md:mb-16"
        >
          <span className="badge bg-teal-100 dark:bg-teal-900/40 text-teal-700 dark:text-teal-300 mb-3">
            Arah & Tujuan
          </span>
          <h2 className="section-title">
            Visi & <span className="text-gradient">Misi Kami</span>
          </h2>
        </motion.div>

        {/* Infographic image — primary display */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.1 }}
          className="relative mb-12 cursor-pointer group"
          onClick={() => setLightbox(true)}
        >
          <div className="relative max-w-2xl mx-auto rounded-2xl border border-teal-200/60 dark:border-teal-700/40 overflow-hidden">
            <Image
              src="/infografis-visi-misi.png"
              alt="Infografis Visi dan Misi Koperasi Mandara Sedana Kuta"
              width={700}
              height={1050}
              sizes="(max-width: 768px) 100vw, 700px"
              className="w-full h-auto transition-transform duration-500 group-hover:scale-105"
              priority
            />
            {/* Overlay */}
            <div className="absolute inset-0 bg-teal-900/0 group-hover:bg-teal-900/20 flex items-center justify-center transition-all duration-300">
              <span className="opacity-0 group-hover:opacity-100 transition-opacity bg-white/90 text-teal-800 px-4 py-2 rounded-xl text-sm font-semibold shadow-lg">
                Klik untuk memperbesar
              </span>
            </div>
          </div>
          {/* Gold corner accents */}
</motion.div>

        {/* Text breakdown */}
        <div className="grid md:grid-cols-2 gap-8">
          {/* Visi */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ delay: 0.2 }}
            className="bg-gradient-to-br from-teal-800 to-teal-900 rounded-2xl p-6 md:p-8 text-white relative overflow-hidden"
          >
<div className="relative z-10">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center">
                  <Eye size={20} className="text-cyan-300" />
                </div>
                <h3 className="text-xl font-bold text-white">VISI</h3>
              </div>
              <p className="text-white/90 leading-relaxed text-sm md:text-base">
                Menjadi koperasi modern dengan jaringan yang luas dan aktif mendukung
                pengembangan usaha anggota melalui ekosistem koperasi yang terintegrasi
                untuk meningkatkan pertumbuhan ekonomi anggota yang berkelanjutan.
              </p>
              {/* Gold accent line */}
              <div className="mt-4 h-0.5 w-16 bg-gradient-to-r from-gold to-transparent rounded-full" />
            </div>
          </motion.div>

          {/* Misi */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ delay: 0.3 }}
            className="card p-6 md:p-8"
          >
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-primary-100 dark:bg-primary-900/30 flex items-center justify-center">
                <Target size={20} className="text-primary-600 dark:text-primary-400" />
              </div>
              <h3 className="text-xl font-bold text-black dark:text-white">MISI</h3>
            </div>
            <ol className="space-y-3">
              {misi.map((m, i) => (
                <motion.li
                  key={i}
                  initial={{ opacity: 0, x: 15 }}
                  animate={isInView ? { opacity: 1, x: 0 } : {}}
                  transition={{ delay: 0.3 + i * 0.08 }}
                  className="flex items-start gap-3 text-sm text-black dark:text-slate-200"
                >
                  <span className="w-6 h-6 rounded-full bg-gradient-teal-cyan flex items-center justify-center text-white text-xs font-bold shrink-0 mt-0.5">
                    {i + 1}
                  </span>
                  <span className="leading-relaxed">{m}</span>
                </motion.li>
              ))}
            </ol>
          </motion.div>
        </div>
      </div>

      {/* Lightbox */}
      {lightbox && (
        <div
          className="fixed inset-0 z-[100] bg-black/90 flex items-center justify-center p-4"
          onClick={() => setLightbox(false)}
          role="dialog"
          aria-modal="true"
          aria-label="Infografis Visi Misi"
        >
          <button
            className="absolute top-4 right-4 w-10 h-10 flex items-center justify-center rounded-full bg-white/10 text-white hover:bg-white/20 transition-colors"
            aria-label="Tutup"
          >
            <X size={20} />
          </button>
          <div
            className="relative max-w-2xl w-full max-h-[90vh] overflow-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <Image
              src="/infografis-visi-misi.png"
              alt="Infografis Visi dan Misi — tampilan besar"
              width={700}
              height={1050}
              sizes="(max-width: 768px) 100vw, 700px"
              className="w-full h-auto rounded-xl"
            />
          </div>
        </div>
      )}
    </section>
  );
}
