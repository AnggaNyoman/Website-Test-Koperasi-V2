"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import Image from "next/image";

// ============================================
// FULL-SCREEN LOADING SCREEN
// Shows logo + animated progress bar + Balinese frame
// ============================================

interface LoadingScreenProps {
  onComplete?: () => void;
}

export default function LoadingScreen({ onComplete }: LoadingScreenProps) {
  const [progress, setProgress] = useState(0);
  const [visible, setVisible] = useState(true);

  useEffect(() => {
    // Simulate loading progress
    const intervals = [
      { delay: 100, value: 20 },
      { delay: 300, value: 45 },
      { delay: 600, value: 70 },
      { delay: 900, value: 90 },
      { delay: 1200, value: 100 },
    ];

    const timers = intervals.map(({ delay, value }) =>
      setTimeout(() => setProgress(value), delay)
    );

    const hideTimer = setTimeout(() => {
      setVisible(false);
      onComplete?.();
    }, 1600);

    return () => {
      timers.forEach(clearTimeout);
      clearTimeout(hideTimer);
    };
  }, [onComplete]);

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          initial={{ opacity: 1 }}
          exit={{ opacity: 0, scale: 1.02 }}
          transition={{ duration: 0.5, ease: "easeInOut" }}
          className="fixed inset-0 z-[9999] flex flex-col items-center justify-center bg-gradient-to-br from-teal-800 via-teal-900 to-slate-900 overflow-hidden"
        >
          {/* Animated floating orbs */}
          <div className="absolute inset-0 overflow-hidden pointer-events-none">
            {[
              { size: 300, x: -10, y: -10, delay: 0 },
              { size: 200, x: 80, y: 60, delay: 0.5 },
              { size: 150, x: -5, y: 75, delay: 1 },
            ].map((orb, i) => (
              <motion.div
                key={i}
                animate={{
                  y: [0, -20, 0],
                  opacity: [0.1, 0.2, 0.1],
                }}
                transition={{
                  duration: 4,
                  delay: orb.delay,
                  repeat: Infinity,
                  ease: "easeInOut",
                }}
                className="absolute rounded-full bg-gradient-to-br from-cyan-500/20 to-primary-500/10"
                style={{
                  width: orb.size,
                  height: orb.size,
                  left: `${orb.x}%`,
                  top: `${orb.y}%`,
                  filter: "blur(60px)",
                }}
              />
            ))}
          </div>

          {/* Content */}
          <div className="relative z-10 flex flex-col items-center gap-8 px-8">
            {/* Logo */}
            <motion.div
              initial={{ scale: 0.5, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              transition={{ duration: 0.6, ease: "easeOut" }}
              className="relative"
            >
              <motion.div
                animate={{ y: [0, -8, 0] }}
                transition={{ duration: 3, repeat: Infinity, ease: "easeInOut" }}
              >
                <div className="w-24 h-24 md:w-32 md:h-32 relative">
                  <Image
                    src="/logo.png"
                    alt="Koperasi Mandara Sedana Kuta"
                    fill
                    sizes="(max-width: 768px) 96px, 128px"
                    className="object-contain drop-shadow-2xl"
                    priority
                  />
                </div>
              </motion.div>

              {/* Glow ring */}
              <motion.div
                animate={{ scale: [1, 1.3, 1], opacity: [0.3, 0, 0.3] }}
                transition={{ duration: 2, repeat: Infinity }}
                className="absolute inset-0 rounded-full bg-primary-500/30 blur-xl"
              />
            </motion.div>

            {/* Text */}
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3, duration: 0.5 }}
              className="text-center"
            >
              <h1 className="text-white font-bold text-xl md:text-3xl tracking-wide">
                Koperasi Mandara Sedana Kuta
              </h1>
              <p className="text-cyan-300 text-sm md:text-base mt-1 tracking-widest uppercase font-light">
                Bersama Wujudkan Impian
              </p>
            </motion.div>

            {/* Progress bar */}
            <motion.div
              initial={{ opacity: 0, width: 0 }}
              animate={{ opacity: 1, width: "100%" }}
              transition={{ delay: 0.5, duration: 0.3 }}
              className="w-64 md:w-80"
            >
              <div className="h-1 bg-white/10 rounded-full overflow-hidden">
                <motion.div
                  className="h-full rounded-full bg-gradient-to-r from-primary-500 via-cyan-400 to-primary-400"
                  style={{ width: `${progress}%` }}
                  transition={{ duration: 0.3, ease: "easeOut" }}
                />
              </div>
              <div className="flex justify-between items-center mt-2">
                <span className="text-white/40 text-xs">Memuat...</span>
                <span className="text-cyan-300 text-xs font-mono">{progress}%</span>
              </div>
            </motion.div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
