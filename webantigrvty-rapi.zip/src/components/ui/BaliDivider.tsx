"use client";

import { BaliLotus, BaliPepatranBorder } from "@/components/ui/BaliOrnament";
interface BaliDividerProps {
  className?: string;
  variant?: "lotus" | "pepatran" | "wave";
  flip?: boolean;
  color?: string;
  opacity?: number;
}

/**
 * Balinese-styled ornamental section divider
 */
export default function BaliDivider({
  className = "",
  variant = "lotus",
  flip = false,
  color = "#D4AF37",
  opacity = 0.2,
}: BaliDividerProps) {
  return (
    <div
      className={`relative flex items-center justify-center py-2 overflow-hidden ${className}`}
      style={{ transform: flip ? "scaleY(-1)" : undefined }}
      aria-hidden="true"
    >
      {variant === "lotus" && (
        <BaliLotus color={color} opacity={opacity} className="max-w-4xl" />
      )}
      {variant === "pepatran" && (
        <BaliPepatranBorder color={color} opacity={opacity} />
      )}
      {variant === "wave" && (
        <svg
          viewBox="0 0 1440 40"
          xmlns="http://www.w3.org/2000/svg"
          className="w-full h-10"
          preserveAspectRatio="none"
          aria-hidden="true"
        >
          <path
            d="M0 20 Q 180 0, 360 20 Q 540 40, 720 20 Q 900 0, 1080 20 Q 1260 40, 1440 20"
            fill="none"
            stroke={color}
            strokeOpacity={opacity}
            strokeWidth="1.5"
          />
          {/* Decorative dots on wave */}
          {[0, 180, 360, 540, 720, 900, 1080, 1260, 1440].map((x) => (
            <circle key={x} cx={x} cy="20" r="3" fill={color} fillOpacity={opacity * 1.5} />
          ))}
        </svg>
      )}
    </div>
  );
}
