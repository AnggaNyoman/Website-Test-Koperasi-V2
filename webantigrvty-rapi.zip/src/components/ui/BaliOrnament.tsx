"use client";

// ============================================
// BALINESE ORNAMENT INLINE SVG COMPONENTS
// Inspired by Keketusan/Pepatran motifs
// ============================================

interface BaliOrnamentProps {
  className?: string;
  opacity?: number;
  color?: string;
}

/** Full-width Balinese lotus/keketusan divider SVG */
export function BaliLotus({ className = "", opacity = 0.15, color = "#D4AF37" }: BaliOrnamentProps) {
  return (
    <svg
      viewBox="0 0 800 80"
      xmlns="http://www.w3.org/2000/svg"
      className={`w-full ${className}`}
      aria-hidden="true"
    >
      <g fill={color} fillOpacity={opacity}>
        {/* Central lotus */}
        <ellipse cx="400" cy="40" rx="30" ry="12" />
        <ellipse cx="400" cy="40" rx="12" ry="30" />
        <ellipse cx="400" cy="40" rx="22" ry="8" transform="rotate(45 400 40)" />
        <ellipse cx="400" cy="40" rx="22" ry="8" transform="rotate(-45 400 40)" />
        <circle cx="400" cy="40" r="5" />
        {/* Left petals */}
        <ellipse cx="340" cy="40" rx="25" ry="8" />
        <ellipse cx="280" cy="40" rx="20" ry="6" />
        <ellipse cx="230" cy="40" rx="15" ry="5" />
        <ellipse cx="190" cy="40" rx="10" ry="4" />
        {/* Right petals */}
        <ellipse cx="460" cy="40" rx="25" ry="8" />
        <ellipse cx="520" cy="40" rx="20" ry="6" />
        <ellipse cx="570" cy="40" rx="15" ry="5" />
        <ellipse cx="610" cy="40" rx="10" ry="4" />
        {/* Small decorative dots */}
        {[160, 130, 100, 640, 670, 700].map((x) => (
          <circle key={x} cx={x} cy="40" r="3" />
        ))}
        {/* Vine curves */}
        <path d="M0 40 Q 80 20, 160 40 Q 240 60, 320 40" fill="none" stroke={color} strokeOpacity={opacity} strokeWidth="1.5" />
        <path d="M480 40 Q 560 20, 640 40 Q 720 60, 800 40" fill="none" stroke={color} strokeOpacity={opacity} strokeWidth="1.5" />
      </g>
    </svg>
  );
}

export interface BaliCornerProps extends BaliOrnamentProps {
  position?: "top-left" | "top-right" | "bottom-left" | "bottom-right";
  size?: number;
}

/** Corner ornament for cards */
export function BaliCorner({
  className = "",
  opacity = 0.2,
  color = "#D4AF37",
  position = "top-left",
  size = 40,
}: BaliCornerProps) {
  const positionClasses: Record<string, string> = {
    "top-left": "top-0 left-0",
    "top-right": "top-0 right-0 -scale-x-100",
    "bottom-left": "bottom-0 left-0 -scale-y-100",
    "bottom-right": "bottom-0 right-0 -scale-x-100 -scale-y-100",
  };

  const posClass = positionClasses[position] || "top-0 left-0";

  return (
    <svg
      viewBox="0 0 60 60"
      xmlns="http://www.w3.org/2000/svg"
      style={{ width: size, height: size }}
      className={`absolute ${posClass} pointer-events-none select-none z-10 ${className}`}
      aria-hidden="true"
    >
      <g fill="none" stroke={color} strokeOpacity={opacity} strokeWidth="1">
        <path d="M2 2 Q 30 2, 30 30" />
        <path d="M2 2 Q 2 30, 30 30" />
        <circle cx="2" cy="2" r="3" fill={color} fillOpacity={opacity * 1.5} />
        <circle cx="30" cy="30" r="2" fill={color} fillOpacity={opacity} />
        <circle cx="16" cy="16" r="5" />
        <circle cx="16" cy="16" r="2" fill={color} fillOpacity={opacity} />
        <path d="M8 8 Q 16 4, 24 8" />
        <path d="M8 8 Q 4 16, 8 24" />
      </g>
    </svg>
  );
}


/** Pepatran border pattern — horizontal repeating */
export function BaliPepatranBorder({ className = "", opacity = 0.1, color = "#D4AF37" }: BaliOrnamentProps) {
  return (
    <svg
      viewBox="0 0 400 20"
      xmlns="http://www.w3.org/2000/svg"
      className={`w-full h-4 ${className}`}
      preserveAspectRatio="xMidYMid meet"
      aria-hidden="true"
    >
      <defs>
        <pattern id="pepatran" x="0" y="0" width="40" height="20" patternUnits="userSpaceOnUse">
          <g fill={color} fillOpacity={opacity}>
            <circle cx="5" cy="10" r="2" />
            <circle cx="20" cy="4" r="3" />
            <circle cx="20" cy="16" r="3" />
            <circle cx="35" cy="10" r="2" />
            <ellipse cx="12" cy="10" rx="5" ry="2" />
            <ellipse cx="28" cy="10" rx="5" ry="2" />
          </g>
          <g fill="none" stroke={color} strokeOpacity={opacity * 0.8} strokeWidth="0.8">
            <path d="M0 10 Q 10 2, 20 10 Q 30 18, 40 10" />
            <path d="M0 10 Q 10 18, 20 10 Q 30 2, 40 10" />
          </g>
        </pattern>
      </defs>
      <rect width="400" height="20" fill="url(#pepatran)" />
    </svg>
  );
}

/** Floating background ornament — large decorative */
export function BaliFloatingOrn({ className = "", opacity = 0.06, color = "#D4AF37" }: BaliOrnamentProps) {
  return (
    <svg
      viewBox="0 0 200 200"
      xmlns="http://www.w3.org/2000/svg"
      className={`absolute pointer-events-none select-none ${className}`}
      aria-hidden="true"
    >
      <g fill={color} fillOpacity={opacity}>
        {/* Lotus base */}
        <ellipse cx="100" cy="100" rx="80" ry="28" />
        <ellipse cx="100" cy="100" rx="28" ry="80" />
        <ellipse cx="100" cy="100" rx="70" ry="24" transform="rotate(45 100 100)" />
        <ellipse cx="100" cy="100" rx="70" ry="24" transform="rotate(-45 100 100)" />
        <ellipse cx="100" cy="100" rx="55" ry="18" transform="rotate(30 100 100)" />
        <ellipse cx="100" cy="100" rx="55" ry="18" transform="rotate(-30 100 100)" />
        <ellipse cx="100" cy="100" rx="55" ry="18" transform="rotate(60 100 100)" />
        <ellipse cx="100" cy="100" rx="55" ry="18" transform="rotate(-60 100 100)" />
        {/* Center */}
        <circle cx="100" cy="100" r="16" />
        <circle cx="100" cy="100" r="8" fillOpacity={opacity * 1.5} />
        {/* Dots ring */}
        {[0, 45, 90, 135, 180, 225, 270, 315].map((deg) => {
          const rad = (deg * Math.PI) / 180;
          const x = 100 + 38 * Math.cos(rad);
          const y = 100 + 38 * Math.sin(rad);
          return <circle key={deg} cx={x} cy={y} r="4" />;
        })}
      </g>
    </svg>
  );
}

/** Keketusan wave pattern for hero background */
export function BaliWavePattern({ className = "", opacity = 0.05, color = "#D4AF37" }: BaliOrnamentProps) {
  return (
    <svg
      viewBox="0 0 1440 160"
      xmlns="http://www.w3.org/2000/svg"
      className={`w-full ${className}`}
      preserveAspectRatio="none"
      aria-hidden="true"
    >
      <defs>
        <pattern id="keketusan" x="0" y="0" width="120" height="80" patternUnits="userSpaceOnUse">
          <g fill="none" stroke={color} strokeOpacity={opacity} strokeWidth="0.8">
            {/* Diamond lattice */}
            <polygon points="60,5 115,40 60,75 5,40" />
            <polygon points="60,15 105,40 60,65 15,40" />
            {/* Inner lotus */}
            <circle cx="60" cy="40" r="10" />
            <circle cx="60" cy="40" r="5" fill={color} fillOpacity={opacity} />
            {/* Petal tips */}
            <line x1="60" y1="5" x2="60" y2="15" strokeWidth="1.5" />
            <line x1="60" y1="65" x2="60" y2="75" strokeWidth="1.5" />
            <line x1="5" y1="40" x2="15" y2="40" strokeWidth="1.5" />
            <line x1="105" y1="40" x2="115" y2="40" strokeWidth="1.5" />
          </g>
        </pattern>
      </defs>
      <rect width="1440" height="160" fill="url(#keketusan)" />
    </svg>
  );
}
