import { MEMBER_TIERS } from "@/lib/constants";
import { CheckCircle2, Crown } from "lucide-react";

export default function MemberTiers() {
  return (
    <section className="section-py bg-slate-50 dark:bg-slate-900/50">
      <div className="section-container">
        <div className="text-center max-w-2xl mx-auto mb-12 md:mb-16">
          <span className="badge bg-teal-100 dark:bg-teal-900/50 text-teal-700 dark:text-teal-300">
            Klasifikasi Anggota
          </span>
          <h2 className="section-title">
            Tingkatan <span className="text-gradient">Keanggotaan</span>
          </h2>
          <p className="section-subtitle">
            Semakin besar total Simpanan Anggota Anda, semakin lengkap manfaat dan perlindungan yang Anda terima.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-5">
          {MEMBER_TIERS.map((tier) => (
            <div
              key={tier.id}
              className="rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-md overflow-hidden flex flex-col"
            >
              <div className={`bg-gradient-to-br ${tier.color} px-5 py-4 text-white`}>
                <Crown className="w-5 h-5 mb-1.5 opacity-90" />
                <h3 className="text-lg font-extrabold">{tier.name}</h3>
                <p className="text-xs opacity-90 mt-1 leading-snug">{tier.threshold}</p>
              </div>
              <ul className="p-5 space-y-2.5 text-xs text-black dark:text-slate-300 flex-1">
                {tier.benefits.map((b, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0 mt-0.5" />
                    <span>{b}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <p className="text-center text-xs text-black dark:text-slate-400 mt-8">
          Klasifikasi anggota disesuaikan otomatis berdasarkan total Simpanan Anggota dan dievaluasi secara berkala oleh koperasi.
        </p>
      </div>
    </section>
  );
}
