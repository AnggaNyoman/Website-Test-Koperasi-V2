"use client";

import { useState, useMemo } from "react";
import { formatRupiah } from "@/lib/utils";
import { SITE_CONFIG } from "@/lib/constants";
import { Calculator, Calendar, DollarSign, Printer, MessageCircle, HelpCircle, ChevronDown, Sparkles } from "lucide-react";

const LOAN_TYPES = [
  { name: "PINJARO (Pinjaman Harian Mikro)", rate: 2.7, maxPlafon: 5000000, minPlafon: 500000, fixedTenor: 3, note: "Bunga asli 0,09%/hari selama 100 hari (setara ±2,7%/bulan, dibulatkan ke 3 bulan pada simulator ini). Angka bulanan di sini hanya estimasi." },
  { name: "Pinjaman Usaha", rate: 1.35, maxPlafon: 100000000, minPlafon: 1000000, minTenor: 12, maxTenor: 60, note: "Bunga riil 1,2%–1,5%/bulan (rata-rata 1,35% dipakai di sini) sesuai penilaian. Plafon riil bebas sesuai pengajuan & nilai agunan, maksimal sebesar BMPP — angka di simulator hanya rentang ilustrasi." },
  { name: "Pinjaman Modal Koperasi", rate: 0, maxPlafon: 10000000, minPlafon: 5000000, plafonStep: 5000000, fixedTenor: 50, note: "Tanpa bunga. Plafon hanya Rp5.000.000 atau Rp10.000.000 (geser slider penuh ke kiri/kanan), tenor tetap 50 bulan." },
  { name: "Pinjaman KPR / Tanah", rate: 1.35, maxPlafon: 150000000, minPlafon: 5000000, minTenor: 12, maxTenor: 120, note: "Bunga riil 1,2%–1,5%/bulan (rata-rata 1,35% dipakai di sini) sesuai penilaian. Plafon riil bebas sesuai pengajuan & nilai agunan (SHM), maksimal sebesar BMPP." },
  { name: "Pinjaman Renovasi", rate: 1.35, maxPlafon: 100000000, minPlafon: 1000000, minTenor: 12, maxTenor: 60, note: "Bunga riil 1,2%–1,5%/bulan (rata-rata 1,35% dipakai di sini) sesuai penilaian. Plafon riil bebas sesuai pengajuan & nilai agunan, maksimal sebesar BMPP." },
  { name: "Pinjaman Investasi", rate: 1.35, maxPlafon: 100000000, minPlafon: 1000000, minTenor: 12, maxTenor: 120, note: "Bunga riil 1,2%–1,5%/bulan (rata-rata 1,35% dipakai di sini) sesuai penilaian. Plafon riil bebas sesuai pengajuan & nilai agunan, maksimal sebesar BMPP." },
  { name: "Pinjaman Sepeda Motor", rate: 1.3, maxPlafon: 50000000, minPlafon: 1000000, minTenor: 12, maxTenor: 24, note: "Bunga 1,3%/bulan. Plafon riil bebas sesuai pengajuan & nilai kendaraan yang dibeli." },
  { name: "Pinjaman Mobil", rate: 1.35, maxPlafon: 100000000, minPlafon: 5000000, minTenor: 12, maxTenor: 60, note: "Bunga riil 1,2%–1,5%/bulan (rata-rata 1,35% dipakai di sini) sesuai penilaian. Plafon riil bebas sesuai pengajuan & nilai kendaraan yang dibeli." },
  { name: "Pinjaman Yadnya", rate: 1.0, maxPlafon: 50000000, minPlafon: 1000000, minTenor: 12, maxTenor: 60, note: "Bunga 1%/bulan. Plafon riil bebas sesuai pengajuan & nilai agunan, maksimal sebesar BMPP." },
  { name: "Pinjaman Multiguna", rate: 1.35, maxPlafon: 50000000, minPlafon: 1000000, minTenor: 12, maxTenor: 60, note: "Bunga riil 1,2%–1,5%/bulan (rata-rata 1,35% dipakai di sini) sesuai penilaian. Plafon riil bebas sesuai pengajuan & nilai agunan, maksimal sebesar BMPP." },
  { name: "Pinjaman Back to Back", rate: 1.5, maxPlafon: 100000000, minPlafon: 1000000, minTenor: 12, maxTenor: 60, note: "Bunga 1,5%/bulan + bunga simpanan yang dijadikan agunan (belum termasuk di angka simulasi ini). Plafon riil maksimal 90% dari nilai agunan (SIRELA/SIJAKA)." },
  { name: "Pinjaman Sinergi Tanpa Agunan", rate: 1.2, maxPlafon: 10000000, minPlafon: 1000000, minTenor: 12, maxTenor: 60, note: "Bunga 1,2%/bulan. Plafon tanpa agunan maksimal Rp10.000.000 sesuai PKS dengan perusahaan." },
];

const TENORS = [1, 3, 6, 12, 24, 36, 60, 84, 120];

export default function LoanSimulator() {
  const [selectedTypeIndex, setSelectedTypeIndex] = useState(0);
  const [plafon, setPlafon] = useState<number>(5000000);
  const [tenor, setTenor] = useState<number>(3);
  const [showSchedule, setShowSchedule] = useState<boolean>(false);

  const currentType = LOAN_TYPES[selectedTypeIndex];
  const ratePerMonth = currentType.rate;
  const visibleTenors = currentType.fixedTenor
    ? [currentType.fixedTenor]
    : TENORS.filter((t) => t >= (currentType.minTenor ?? 1) && t <= (currentType.maxTenor ?? 120));

  const handleSelectType = (idx: number) => {
    const type = LOAN_TYPES[idx];
    setSelectedTypeIndex(idx);
    if (type.fixedTenor) {
      setTenor(type.fixedTenor);
    } else {
      setTenor((prev) => {
        const min = type.minTenor ?? 1;
        const max = type.maxTenor ?? 120;
        if (prev < min || prev > max) {
          const options = TENORS.filter((t) => t >= min && t <= max);
          return options[0] ?? min;
        }
        return prev;
      });
    }
    setPlafon((prev) => {
      const clamped = Math.min(Math.max(prev, type.minPlafon ?? 500000), type.maxPlafon);
      return clamped;
    });
  };

  // Real-time calculations
  const calculations = useMemo(() => {
    const pokokPerBulan = Math.round(plafon / tenor);
    const bungaPerBulan = Math.round(plafon * (ratePerMonth / 100));
    const angsuranPerBulan = pokokPerBulan + bungaPerBulan;
    const totalBunga = bungaPerBulan * tenor;
    const totalPengembalian = plafon + totalBunga;
    // Biaya administrasi (sesuai tenor) & provisi 0,5% — kecuali PINJARO (hanya materai) & Modal Koperasi (admin flat)
    const isPinjaro = currentType.name.startsWith("PINJARO");
    const isModalKoperasi = currentType.name === "Pinjaman Modal Koperasi";
    const tenorTahun = tenor / 12;
    const adminRate = tenorTahun <= 2 ? 0.01 : tenorTahun <= 4 ? 0.015 : 0.02;
    const biayaProvisi = isPinjaro || isModalKoperasi ? 0 : Math.round(plafon * 0.005);
    const biayaAdmin = isPinjaro
      ? 10000
      : isModalKoperasi
      ? plafon <= 5000000 ? 50000 : 100000
      : Math.round(plafon * adminRate);
    const danaDiterima = plafon - biayaProvisi - biayaAdmin;

    // Amortization schedule
    const schedule = [];
    let sisaPokok = plafon;
    for (let m = 1; m <= tenor; m++) {
      const pokok = m === tenor ? sisaPokok : pokokPerBulan;
      sisaPokok = Math.max(0, sisaPokok - pokok);
      schedule.push({
        bulan: m,
        pokok,
        bunga: bungaPerBulan,
        total: pokok + bungaPerBulan,
        sisaPokok,
      });
    }

    return {
      pokokPerBulan,
      bungaPerBulan,
      angsuranPerBulan,
      totalBunga,
      totalPengembalian,
      biayaProvisi,
      biayaAdmin,
      danaDiterima,
      schedule,
    };
  }, [plafon, tenor, ratePerMonth, currentType]);

  const handlePrint = () => {
    window.print();
  };

  const waMessage = `Halo Koperasi Mandara Sedana Kuta, saya ingin konsultasi simulasi pinjaman:\n- Jenis: ${currentType.name}\n- Plafon: ${formatRupiah(plafon)}\n- Tenor: ${tenor} Bulan\n- Angsuran per bulan: ${formatRupiah(calculations.angsuranPerBulan)}`;
  const waUrl = `https://wa.me/${SITE_CONFIG.whatsapp}?text=${encodeURIComponent(waMessage)}`;

  return (
    <div className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-xl overflow-hidden print:border-none print:shadow-none">
      <div className="p-6 sm:p-8 bg-gradient-to-r from-teal-800 to-teal-900 text-white relative">
<div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center text-teal-300">
            <Calculator className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-bold">Kalkulator Simulasi Pinjaman</h2>
            <p className="text-teal-200 text-xs sm:text-sm">
              Perhitungan suku bunga flat tetap per bulan dengan rincian biaya transparan
            </p>
          </div>
        </div>
      </div>

      <div className="p-6 sm:p-8 grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Input Controls */}
        <div className="lg:col-span-6 space-y-6">
          {/* Jenis Pinjaman */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-black dark:text-slate-400 mb-2">
              Jenis Pinjaman
            </label>
            <select
              value={selectedTypeIndex}
              onChange={(e) => handleSelectType(Number(e.target.value))}
              className="w-full p-3 rounded-xl text-sm font-semibold border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-black dark:text-slate-200 focus:outline-none focus:ring-2 focus:ring-teal-500"
            >
              {LOAN_TYPES.map((type, idx) => (
                <option key={idx} value={idx}>
                  {type.name} {type.rate > 0 ? `— ${type.rate}%/bln` : "— Tanpa Bunga"}
                </option>
              ))}
            </select>
            {currentType.note && (
              <p className="text-[11px] text-amber-700 dark:text-amber-300 mt-1.5 leading-snug">
                ⓘ {currentType.note}
              </p>
            )}
          </div>

          {/* Plafon Pinjaman Slider + Custom Input */}
          <div>
            <div className="flex justify-between items-center mb-2 gap-2">
              <label className="text-xs font-bold uppercase tracking-wider text-black dark:text-slate-400">
                Plafon Pinjaman
              </label>
              <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-700/60 rounded-lg px-2 py-1">
                <span className="text-teal-600 dark:text-teal-400 font-bold text-xs sm:text-sm">Rp</span>
                <input
                  type="number"
                  value={plafon}
                  onChange={(e) => setPlafon(Number(e.target.value) || 0)}
                  onBlur={(e) => {
                    const val = Number(e.target.value) || 0;
                    const clamped = Math.min(Math.max(val, currentType.minPlafon ?? 500000), currentType.maxPlafon);
                    setPlafon(clamped);
                  }}
                  className="w-28 sm:w-36 font-mono text-sm sm:text-base font-bold text-teal-600 dark:text-teal-400 bg-transparent focus:outline-none text-right"
                />
              </div>
            </div>
            <input
              type="range"
              min={currentType.minPlafon ?? 500000}
              max={currentType.maxPlafon}
              step={currentType.plafonStep ?? 500000}
              value={Math.min(Math.max(plafon, currentType.minPlafon ?? 500000), currentType.maxPlafon)}
              onChange={(e) => setPlafon(Number(e.target.value))}
              className="w-full accent-teal-600 h-2 bg-slate-200 dark:bg-slate-700 rounded-lg cursor-pointer"
            />
            <div className="flex justify-between text-[11px] text-black mt-1">
              <span>Min: {formatRupiah(currentType.minPlafon ?? 500000)}</span>
              <span>Maks: {formatRupiah(currentType.maxPlafon)}</span>
            </div>
            <p className="text-[10px] text-black dark:text-slate-500 mt-1">
              Bisa ketik nominal sendiri di kotak angka di atas.
            </p>
          </div>

          {/* Jangka Waktu (Tenor) */}
          <div>
            <div className="flex justify-between items-center mb-2">
              <label className="text-xs font-bold uppercase tracking-wider text-black dark:text-slate-400">
                Jangka Waktu (Tenor)
              </label>
              <span className="font-bold text-black dark:text-slate-200 text-sm">
                {tenor} Bulan ({Math.round((tenor / 12) * 10) / 10} Tahun)
              </span>
            </div>
            {currentType.fixedTenor ? (
              <p className="text-xs text-black dark:text-slate-300 bg-slate-100 dark:bg-slate-700/50 rounded-xl p-3">
                Tenor untuk produk ini tetap: <strong>{currentType.fixedTenor} bulan</strong>.
              </p>
            ) : (
              <div className="grid grid-cols-3 sm:grid-cols-5 gap-1.5">
                {visibleTenors.map((t) => (
                  <button
                    key={t}
                    type="button"
                    onClick={() => setTenor(t)}
                    className={`py-2 px-1 rounded-xl text-xs font-bold transition-all border ${
                      tenor === t
                        ? "bg-teal-600 text-white border-teal-600 shadow"
                        : "bg-slate-50 dark:bg-slate-700/50 border-slate-200 dark:border-slate-700 text-black dark:text-slate-300 hover:border-teal-500"
                    }`}
                  >
                    {t} Bln
                  </button>
                ))}
              </div>
            )}
          </div>

          <div className="p-4 rounded-xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 text-[11px] text-amber-800 dark:text-amber-200 flex gap-2">
            <HelpCircle className="w-4 h-4 shrink-0 text-amber-600 mt-0.5" />
            <span>
              Perhitungan bersifat estimasi simulasi. Persetujuan dan plafon aktual ditentukan setelah analisis kelayakan oleh komite kredit Koperasi.
            </span>
          </div>
        </div>

        {/* Output Summary Card */}
        <div className="lg:col-span-6 flex flex-col justify-between">
          <div className="bg-slate-50 dark:bg-slate-900/80 rounded-2xl p-6 border border-slate-200 dark:border-slate-700 relative">
<div className="text-center pb-6 border-b border-slate-200 dark:border-slate-700">
              <span className="text-xs uppercase tracking-wider font-bold text-black dark:text-slate-400">
                Estimasi Angsuran Bulanan
              </span>
              <div className="text-3xl sm:text-4xl font-extrabold text-teal-600 dark:text-teal-400 font-mono mt-1">
                {formatRupiah(calculations.angsuranPerBulan)}
              </div>
              <span className="text-xs text-black dark:text-slate-400">
                per bulan selama {tenor} bulan
              </span>
            </div>

            <div className="py-4 space-y-2.5 text-xs sm:text-sm">
              <div className="flex justify-between">
                <span className="text-black dark:text-slate-400">Pokok Pinjaman:</span>
                <span className="font-bold text-black dark:text-slate-200 font-mono">
                  {formatRupiah(plafon)}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-black dark:text-slate-400">Pokok per Bulan:</span>
                <span className="font-semibold text-black dark:text-slate-300 font-mono">
                  {formatRupiah(calculations.pokokPerBulan)}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-black dark:text-slate-400">Bunga per Bulan ({ratePerMonth}%):</span>
                <span className="font-semibold text-black dark:text-slate-300 font-mono">
                  {formatRupiah(calculations.bungaPerBulan)}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-black dark:text-slate-400">Total Bunga ({tenor} bln):</span>
                <span className="font-semibold text-black dark:text-slate-300 font-mono">
                  {formatRupiah(calculations.totalBunga)}
                </span>
              </div>
              <div className="flex justify-between pt-2 border-t border-slate-200 dark:border-slate-700">
                <span className="text-black dark:text-slate-300 font-semibold">Total Pengembalian:</span>
                <span className="font-bold text-teal-700 dark:text-teal-300 font-mono">
                  {formatRupiah(calculations.totalPengembalian)}
                </span>
              </div>

              {/* Rincian Potongan Awal */}
              <div className="pt-3 border-t border-dashed border-slate-200 dark:border-slate-700 text-xs">
                <div className="text-[11px] font-bold text-black uppercase tracking-wider mb-1">
                  Biaya di Awal (Diproses Saat Pencairan):
                </div>
                <div className="flex justify-between text-black">
                  <span>Provisi (0,5%):</span>
                  <span className="font-mono">{formatRupiah(calculations.biayaProvisi)}</span>
                </div>
                <div className="flex justify-between text-black">
                  <span>Admin / Materai:</span>
                  <span className="font-mono">{formatRupiah(calculations.biayaAdmin)}</span>
                </div>
                <div className="flex justify-between font-bold text-emerald-600 dark:text-emerald-400 pt-1">
                  <span>Estimasi Dana Diterima Bersih:</span>
                  <span className="font-mono">{formatRupiah(calculations.danaDiterima)}</span>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="mt-4 pt-4 border-t border-slate-200 dark:border-slate-700 flex flex-col sm:flex-row gap-2">
              <a
                href={waUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex-1 inline-flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2.5 px-4 rounded-xl text-xs transition-colors shadow"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Ajukan via WhatsApp</span>
              </a>
              <button
                type="button"
                onClick={handlePrint}
                className="inline-flex items-center justify-center gap-1.5 bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 text-black dark:text-slate-200 font-semibold py-2.5 px-3 rounded-xl text-xs transition-colors"
              >
                <Printer className="w-4 h-4" />
                <span>Cetak</span>
              </button>
            </div>
          </div>

          <button
            type="button"
            onClick={() => setShowSchedule(!showSchedule)}
            className="w-full mt-4 flex items-center justify-between p-3 rounded-xl bg-slate-100 dark:bg-slate-700/50 hover:bg-slate-200 dark:hover:bg-slate-700 text-black dark:text-slate-200 text-xs font-bold transition-colors"
          >
            <span>{showSchedule ? "Sembunyikan" : "Tampilkan"} Jadwal Angsuran {tenor} Bulan</span>
            <ChevronDown className={`w-4 h-4 transform transition-transform ${showSchedule ? "rotate-180" : ""}`} />
          </button>
        </div>
      </div>

      {/* Amortization Schedule Table */}
      {showSchedule && (
        <div className="p-6 sm:p-8 border-t border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900/40">
          <h3 className="text-base font-bold text-black dark:text-white mb-4 flex items-center gap-2">
            <Calendar className="w-4 h-4 text-teal-600" />
            <span>Tabel Jadwal Angsuran Pinjaman</span>
          </h3>
          <div className="overflow-x-auto rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-100 dark:bg-slate-700 text-black dark:text-slate-300 font-bold uppercase border-b border-slate-200 dark:border-slate-700">
                <tr>
                  <th className="px-4 py-3">Bulan Ke</th>
                  <th className="px-4 py-3">Angsuran Pokok</th>
                  <th className="px-4 py-3">Bunga</th>
                  <th className="px-4 py-3">Total Angsuran</th>
                  <th className="px-4 py-3">Sisa Pokok Pinjaman</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-700 font-mono">
                {calculations.schedule.map((row) => (
                  <tr key={row.bulan} className="hover:bg-slate-50 dark:hover:bg-slate-700/50">
                    <td className="px-4 py-2.5 font-bold font-sans">{row.bulan}</td>
                    <td className="px-4 py-2.5">{formatRupiah(row.pokok)}</td>
                    <td className="px-4 py-2.5">{formatRupiah(row.bunga)}</td>
                    <td className="px-4 py-2.5 font-bold text-teal-600 dark:text-teal-400">
                      {formatRupiah(row.total)}
                    </td>
                    <td className="px-4 py-2.5 text-black">{formatRupiah(row.sisaPokok)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
