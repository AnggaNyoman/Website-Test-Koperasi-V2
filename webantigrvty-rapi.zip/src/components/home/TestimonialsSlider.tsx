"use client";

import { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Star, ChevronLeft, ChevronRight, Quote } from "lucide-react";
import { TESTIMONIALS } from "@/lib/constants";
// ============================================
// TESTIMONIALS SLIDER
// ============================================

export default function TestimonialsSlider() {
  const [current, setCurrent] = useState(0);
  const total = TESTIMONIALS.length;

  const next = useCallback(() => setCurrent((c) => (c + 1) % total), [total]);
  const prev = useCallback(() => setCurrent((c) => (c - 1 + total) % total), [total]);

  useEffect(() => {
    const id = setInterval(next, 6000);
    return () => clearInterval(id);
  }, [next]);

  const testimonial = TESTIMONIALS[current];

  return (
    <section className="section-py bg-white dark:bg-slate-900 relative overflow-hidden">

      <div className="section-container relative z-10">
        {/* Header */}
        <div className="text-center mb-10 space-y-2">
          <span className="badge bg-primary-100 dark:bg-primary-900/30 text-primary-700 dark:text-primary-300">
            ⭐ Testimoni Anggota
          </span>
          <h2 className="section-title">
            Kata Mereka tentang{" "}
            <span className="text-gradient">Mandara Sedana Kuta</span>
          </h2>
        </div>

        {/* Slider */}
        <div className="relative max-w-3xl mx-auto">
          <AnimatePresence mode="wait">
            <motion.div
              key={current}
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -30 }}
              transition={{ duration: 0.4 }}
              className="card p-8 md:p-10 text-center space-y-6"
            >
              {/* Quote icon */}
              <div className="flex justify-center">
                <div className="w-12 h-12 rounded-full bg-primary-100 dark:bg-primary-900/30 flex items-center justify-center">
                  <Quote size={22} className="text-primary-500 fill-primary-500" />
                </div>
              </div>

              {/* Stars */}
              <div className="flex justify-center gap-1">
                {Array.from({ length: testimonial.rating }).map((_, i) => (
                  <Star key={i} size={18} className="text-amber-400 fill-amber-400" />
                ))}
              </div>

              {/* Content */}
              <blockquote className="text-black dark:text-slate-200 text-base md:text-lg leading-relaxed italic">
                &ldquo;{testimonial.content}&rdquo;
              </blockquote>

              {/* Author */}
              <div className="flex flex-col items-center gap-1">
                <div className="w-12 h-12 rounded-full bg-gradient-teal-cyan flex items-center justify-center text-white font-bold text-xl">
                  {testimonial.name.charAt(0)}
                </div>
                <p className="font-semibold text-black dark:text-white mt-1">
                  {testimonial.name}
                </p>
                <p className="text-sm text-black dark:text-slate-400">
                  {testimonial.role}
                </p>
                {testimonial.location && (
                  <p className="text-xs text-cyan-600 dark:text-cyan-400">
                    {testimonial.location}
                  </p>
                )}
              </div>
            </motion.div>
          </AnimatePresence>

          {/* Navigation */}
          <button
            onClick={prev}
            aria-label="Testimoni sebelumnya"
            className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-4 md:-translate-x-8 w-10 h-10 flex items-center justify-center rounded-full bg-white dark:bg-slate-800 shadow-card-hover border border-slate-100 dark:border-slate-700 text-black dark:text-slate-300 hover:bg-teal-50 dark:hover:bg-teal-900/30 hover:text-teal-700 dark:hover:text-cyan-400 transition-all"
          >
            <ChevronLeft size={18} />
          </button>
          <button
            onClick={next}
            aria-label="Testimoni berikutnya"
            className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-4 md:translate-x-8 w-10 h-10 flex items-center justify-center rounded-full bg-white dark:bg-slate-800 shadow-card-hover border border-slate-100 dark:border-slate-700 text-black dark:text-slate-300 hover:bg-teal-50 dark:hover:bg-teal-900/30 hover:text-teal-700 dark:hover:text-cyan-400 transition-all"
          >
            <ChevronRight size={18} />
          </button>
        </div>

        {/* Dots */}
        <div className="flex justify-center gap-2 mt-6">
          {TESTIMONIALS.map((_, i) => (
            <button
              key={i}
              onClick={() => setCurrent(i)}
              aria-label={`Testimoni ${i + 1}`}
              className={`transition-all duration-300 rounded-full ${
                i === current
                  ? "w-6 h-2 bg-primary-500"
                  : "w-2 h-2 bg-slate-200 dark:bg-slate-700 hover:bg-slate-300"
              }`}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
