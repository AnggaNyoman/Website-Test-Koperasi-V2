"use client";

import { useRef, useEffect, useState } from "react";
import Image from "next/image";
import { motion, useInView } from "framer-motion";
import { Wallet, Phone, Zap, ArrowUpRight, Shield, Fingerprint, Smartphone } from "lucide-react";
import dynamic from "next/dynamic";
import { SITE_CONFIG, MADATA_FEATURES } from "@/lib/constants";
import { getMobileOS } from "@/lib/utils";
// Lazy load QR code (heavy lib)
const QRCodeSVG = dynamic(
  () => import("qrcode.react").then((m) => m.QRCodeSVG),
  { ssr: false, loading: () => <div className="w-32 h-32 skeleton" /> }
);

// ============================================
// MADATA MOBILE SECTION — HOME PAGE
// ============================================

const featureIconMap: Record<string, React.ElementType> = {
  Wallet, Phone, Zap, ArrowUpRight, Shield, Fingerprint,
};

export default function MadataMobileSection() {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, margin: "-80px" });
  const [os, setOs] = useState<"android" | "ios" | "other">("other");

  useEffect(() => { setOs(getMobileOS()); }, []);

  const features = MADATA_FEATURES;

  return (
    <section
      ref={ref}
      className="section-py bg-gradient-to-br from-teal-800 via-teal-900 to-slate-900 relative overflow-hidden"
      id="madata"
    >
      {/* BG ornaments */}
<div className="absolute top-0 right-0 w-1/2 h-full bg-gradient-to-l from-cyan-900/20 to-transparent pointer-events-none" />

      <div className="section-container relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* LEFT: Content */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6 }}
            className="space-y-6"
          >
            <div className="space-y-3">
              <span className="badge bg-primary-500/20 text-primary-300 border border-primary-500/30">
                Aplikasi Mobile Banking
              </span>
              <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-white leading-tight">
                Madata Mobile —{" "}
                <span className="text-gradient-green">Koperasi di Genggaman</span>
              </h2>
              <p className="text-slate-300 text-base md:text-lg leading-relaxed">
                Akses layanan koperasi kapan saja, di mana saja. Cek saldo, bayar
                tagihan, top up, dan banyak lagi — langsung dari smartphone Anda.
              </p>
            </div>

            {/* Feature grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {features.map((f, i) => {
                const Icon = featureIconMap[f.icon] || Wallet;
                return (
                  <motion.div
                    key={f.title}
                    initial={{ opacity: 0, y: 15 }}
                    animate={isInView ? { opacity: 1, y: 0 } : {}}
                    transition={{ delay: 0.1 + i * 0.07 }}
                    className="flex items-start gap-3 p-3 rounded-xl bg-white/5 border border-white/10 hover:bg-white/10 transition-colors group"
                  >
                    <div className="w-9 h-9 rounded-xl bg-primary-500/20 flex items-center justify-center shrink-0 group-hover:bg-primary-500/30 transition-colors">
                      <Icon size={16} className="text-primary-400" />
                    </div>
                    <div>
                      <p className="text-white text-sm font-semibold">{f.title}</p>
                      <p className="text-black text-xs mt-0.5 leading-relaxed">{f.description}</p>
                    </div>
                  </motion.div>
                );
              })}
            </div>

            {/* Download Buttons */}
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: 0.5 }}
              className="flex flex-wrap items-center gap-3"
            >
              <a
                href={SITE_CONFIG.googlePlayUrl}
                target="_blank"
                rel="noopener noreferrer"
                id="btn-download-playstore"
                className="inline-block transition-transform hover:-translate-y-0.5"
              >
                <img
                  src="/badges/google-play-badge.svg"
                  alt="Unduh di Google Play"
                  className="h-11 w-auto"
                />
              </a>

              <div className="relative inline-block opacity-50 cursor-not-allowed" title="Segera tersedia">
                <img
                  src="/badges/app-store-badge.svg"
                  alt="Segera hadir di App Store"
                  className="h-11 w-auto grayscale"
                />
              </div>
            </motion.div>

            {/* Smart OS hint */}
            {os === "android" && (
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-xs text-primary-400 flex items-center gap-1"
              >
                <Smartphone size={12} />
                Terdeteksi perangkat Android — klik Google Play untuk download langsung!
              </motion.p>
            )}
          </motion.div>

          {/* RIGHT: Logo + QR */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="flex flex-col items-center gap-8"
          >
            {/* App Logo mockup */}
            <div className="relative">
              <motion.div
                animate={{ y: [0, -12, 0] }}
                transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                className="relative w-48 h-48 sm:w-64 sm:h-64"
              >
                <Image
                  src="/madata-logo.png"
                  alt="Madata Mobile App"
                  fill
                  sizes="(max-width: 640px) 192px, 256px"
                  className="object-contain relative z-10 drop-shadow-2xl"
                />
              </motion.div>
            </div>

            {/* QR Code card */}
            <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-5 flex flex-col items-center gap-3">
              <p className="text-white text-sm font-semibold">Scan untuk Download</p>
              <div className="bg-white p-3 rounded-xl">
                <QRCodeSVG
                  value={SITE_CONFIG.googlePlayUrl}
                  size={120}
                  bgColor="#ffffff"
                  fgColor="#065A74"
                  level="H"
                />
              </div>
              <p className="text-black text-xs text-center">
                Scan QR Code dengan kamera smartphone Anda
              </p>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
