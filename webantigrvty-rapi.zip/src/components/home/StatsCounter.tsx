"use client";

import { useEffect, useRef, useState } from "react";
import { motion, useInView } from "framer-motion";
import { Users, TrendingUp, Calendar, MapPin } from "lucide-react";
import { STATS } from "@/lib/constants";
// ============================================
// ANIMATED STATISTICS COUNTER
// Triggers when scrolled into view
// ============================================

const iconMap: Record<string, React.ElementType> = {
  Users,
  TrendingUp,
  Calendar,
  MapPin,
};

function CountUp({
  target,
  duration = 2000,
  started,
}: {
  target: number;
  duration?: number;
  started: boolean;
}) {
  const [count, setCount] = useState(0);

  useEffect(() => {
    if (!started) return;
    let startTime: number | null = null;
    const startValue = 0;

    const step = (timestamp: number) => {
      if (!startTime) startTime = timestamp;
      const elapsed = timestamp - startTime;
      const progress = Math.min(elapsed / duration, 1);
      // Easing: ease-out-cubic
      const eased = 1 - Math.pow(1 - progress, 3);
      setCount(Math.floor(startValue + eased * (target - startValue)));
      if (progress < 1) requestAnimationFrame(step);
    };

    requestAnimationFrame(step);
  }, [started, target, duration]);

  return <>{count}</>;
}

export default function StatsCounter() {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section ref={ref} className="py-12 md:py-16 bg-white dark:bg-slate-900 relative overflow-hidden">
      {/* Subtle bg pattern */}
<div className="section-container">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-8">
          {STATS.map((stat, i) => {
            const Icon = iconMap[stat.icon] || Users;
            return (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 30 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ delay: i * 0.1, duration: 0.5 }}
                className="relative text-center group"
              >
                {/* Card */}
                <div className="card-hover p-6 lg:p-8 flex flex-col items-center gap-3">
                  {/* Icon */}
                  <div
                    className={`w-12 h-12 rounded-2xl bg-gradient-teal-cyan flex items-center justify-center ${stat.color} text-white`}
                  >
                    <Icon size={22} className="text-white" />
                  </div>

                  {/* Value */}
                  <div className="text-3xl md:text-4xl lg:text-5xl font-bold text-black dark:text-white tabular-nums">
                    {stat.prefix && (
                      <span className="text-2xl md:text-3xl text-black dark:text-slate-400">
                        {stat.prefix}
                      </span>
                    )}
                    <CountUp
                      target={stat.value}
                      started={isInView}
                      duration={2000 + i * 200}
                    />
                    {stat.suffix && (
                      <span className={`${stat.color} text-2xl md:text-3xl font-bold`}>
                        {stat.suffix}
                      </span>
                    )}
                  </div>

                  {/* Label */}
                  <p className="text-sm md:text-base text-black dark:text-slate-400 font-medium text-center leading-tight">
                    {stat.label}
                  </p>

                  {/* Bottom accent line */}
                  <div className="w-8 h-0.5 rounded-full bg-gradient-to-r from-primary-500 to-cyan-500 group-hover:w-full transition-all duration-500" />
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
