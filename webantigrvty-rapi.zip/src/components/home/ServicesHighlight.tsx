"use client";

import { useRef } from "react";
import Link from "next/link";
import { motion, useInView } from "framer-motion";
import { Wallet, PiggyBank, Coins, Clock, Briefcase, CreditCard, GraduationCap, Zap, ArrowRight } from "lucide-react";
import { SERVICES } from "@/lib/constants";

// ============================================
// SERVICES HIGHLIGHT — HOME PAGE
// ============================================

const iconMap: Record<string, React.ElementType> = {
  Wallet,
  PiggyBank,
  Coins,
  Clock,
  Briefcase,
  CreditCard,
  GraduationCap,
  Zap,
};

export default function ServicesHighlight() {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, margin: "-80px" });

  const simpanan = SERVICES.filter((s) => s.category === "simpanan");
  const pinjaman = SERVICES.filter((s) => s.category === "pinjaman");

  return (
    <section ref={ref} className="section-py bg-slate-50 dark:bg-slate-900/50 relative overflow-hidden">
<div className="section-container">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          className="text-center mb-12 md:mb-16 space-y-3"
        >
          <span className="badge bg-teal-100 dark:bg-teal-900/50 text-teal-700 dark:text-teal-300">
            Layanan Unggulan
          </span>
          <h2 className="section-title">
            Solusi Keuangan{" "}
            <span className="text-gradient">Lengkap & Terpercaya</span>
          </h2>
          <p className="section-subtitle mx-auto">
            Dari simpanan hingga pinjaman, semua kebutuhan keuangan Anda tersedia
            di satu tempat dengan bunga kompetitif dan proses mudah.
          </p>
        </motion.div>

        {/* Simpanan Section */}
        <div className="mb-10">
          <h3 className="text-lg font-bold text-teal-700 dark:text-teal-300 mb-5 flex items-center gap-2">
            <PiggyBank size={20} />
            Produk Simpanan
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {simpanan.map((service, i) => {
              const Icon = iconMap[service.icon] || Wallet;
              return (
                <motion.div
                  key={service.id}
                  initial={{ opacity: 0, y: 25 }}
                  animate={isInView ? { opacity: 1, y: 0 } : {}}
                  transition={{ delay: i * 0.08 }}
                  className="group card-hover p-5 flex flex-col gap-3"
                >
                  <div
                    className={`w-11 h-11 rounded-xl bg-gradient-to-br ${service.color} flex items-center justify-center`}
                  >
                    <Icon size={20} className="text-white" />
                  </div>
                  <h4 className="font-semibold text-black dark:text-white text-sm">
                    {service.title}
                  </h4>
                  <p className="text-xs text-black dark:text-slate-400 leading-relaxed flex-1">
                    {service.description}
                  </p>
                </motion.div>
              );
            })}
          </div>
        </div>

{/* Pinjaman Section */}
        <div>
          <h3 className="text-lg font-bold text-primary-600 dark:text-primary-400 mb-5 flex items-center gap-2">
            <Briefcase size={20} />
            Produk Pinjaman
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {pinjaman.map((service, i) => {
              const Icon = iconMap[service.icon] || Briefcase;
              return (
                <motion.div
                  key={service.id}
                  initial={{ opacity: 0, y: 25 }}
                  animate={isInView ? { opacity: 1, y: 0 } : {}}
                  transition={{ delay: 0.3 + i * 0.08 }}
                  className="group card-hover p-5 flex flex-col gap-3"
                >
                  <div
                    className={`w-11 h-11 rounded-xl bg-gradient-to-br ${service.color} flex items-center justify-center`}
                  >
                    <Icon size={20} className="text-white" />
                  </div>
                  <h4 className="font-semibold text-black dark:text-white text-sm">
                    {service.title}
                  </h4>
                  <p className="text-xs text-black dark:text-slate-400 leading-relaxed flex-1">
                    {service.description}
                  </p>
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.6 }}
          className="text-center mt-10"
        >
          <Link href="/layanan" className="btn-primary">
            Lihat Semua Layanan
            <ArrowRight size={18} />
          </Link>
        </motion.div>
      </div>
    </section>
  );
}
