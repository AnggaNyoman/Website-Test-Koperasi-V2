"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowRight, Phone, UserPlus, CheckCircle2 } from "lucide-react";
import { WHATSAPP_URL } from "@/lib/constants";
// ============================================
// CTA SECTION — "Siap Bergabung?"
// ============================================

export default function CTASection() {
  return (
    <section className="section-py bg-gradient-to-br from-teal-800 to-cyan-700 relative overflow-hidden">
      <div className="section-container relative z-10 text-center space-y-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="space-y-4"
        >
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-white">
            Siap Bergabung Bersama Kami?
          </h2>
          <p className="text-white/80 text-base md:text-lg max-w-2xl mx-auto leading-relaxed">
            Jadilah bagian dari keluarga besar Koperasi Mandara Sedana Kuta. Wujudkan
            impian keuangan Anda bersama lebih dari 2.231 anggota aktif di seluruh Bali.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.2, duration: 0.5 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-4"
        >
          <Link
            href="/daftar-anggota"
            className="inline-flex items-center gap-2 px-8 py-4 bg-primary-500 text-black font-bold text-base rounded-2xl hover:bg-primary-400 hover:shadow-glow-green active:scale-95 transition-all duration-200 shadow-lg"
          >
            <UserPlus size={20} />
            Daftar Anggota Sekarang
            <ArrowRight size={18} />
          </Link>
          <a
            href={WHATSAPP_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 px-8 py-4 bg-white/10 backdrop-blur-sm text-white font-semibold text-base rounded-2xl border border-white/25 hover:bg-white/20 active:scale-95 transition-all duration-200"
          >
            <Phone size={20} />
            Hubungi via WhatsApp
          </a>
        </motion.div>

        {/* Trust badges */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.4 }}
          className="flex flex-wrap justify-center gap-x-8 gap-y-2 text-white/60 text-xs"
        >
          <span className="flex items-center gap-1.5">
            <CheckCircle2 size={14} className="text-primary-400 shrink-0" />
            Badan Hukum Resmi Kemenkop
          </span>
          <span className="flex items-center gap-1.5">
            <CheckCircle2 size={14} className="text-primary-400 shrink-0" />
            Diawasi Dinas Koperasi Prov. Bali
          </span>
          <span className="flex items-center gap-1.5">
            <CheckCircle2 size={14} className="text-primary-400 shrink-0" />
            SHU 8%/Tahun
          </span>
          <span className="flex items-center gap-1.5">
            <CheckCircle2 size={14} className="text-primary-400 shrink-0" />
            Layanan Digital 24/7
          </span>
        </motion.div>
      </div>
    </section>
  );
}
