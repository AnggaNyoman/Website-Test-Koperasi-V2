"use client";

import { useState } from "react";
import Image from "next/image";
import { motion, AnimatePresence } from "framer-motion";
import { VIDEOS } from "@/lib/constants";
import { VideoItem } from "@/types";
import { Play, Film } from "lucide-react";
import VideoModal from "./VideoModal";

const CATEGORIES = ["Semua", "Profil", "Komunitas", "Podcast", "Sosial"];

export default function VideoGallery() {
  const [selectedCategory, setSelectedCategory] = useState("Semua");
  const [activeVideo, setActiveVideo] = useState<VideoItem | null>(null);
  const [imgErrors, setImgErrors] = useState<Record<string, boolean>>({});

  const filteredVideos = VIDEOS.filter((v) => {
    if (selectedCategory === "Semua") return true;
    return v.category === selectedCategory;
  });

  return (
    <div>
      {/* Filter Tabs */}
      <div className="flex flex-wrap justify-center gap-2 sm:gap-3 mb-12">
        {CATEGORIES.map((cat) => {
          const isActive = selectedCategory === cat;
          return (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-5 py-2.5 rounded-full text-xs sm:text-sm font-bold transition-all shadow-sm ${
                isActive
                  ? "bg-teal-600 text-white shadow-teal-500/25 shadow-md scale-105"
                  : "bg-white dark:bg-slate-800 text-black dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:border-teal-500"
              }`}
            >
              {cat}
            </button>
          );
        })}
      </div>

      {/* Videos Grid */}
      <motion.div layout className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <AnimatePresence>
          {filteredVideos.map((video) => {
            const hasError = imgErrors[video.id];
            const thumbUrl = hasError
              ? `https://img.youtube.com/vi/${video.videoId}/hqdefault.jpg`
              : video.thumbnail;

            return (
              <motion.div
                key={video.id}
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.3 }}
                className="group cursor-pointer rounded-2xl overflow-hidden bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-md hover:shadow-xl transition-all duration-300 flex flex-col"
                onClick={() => setActiveVideo(video)}
              >
                {/* Thumbnail Container */}
                <div className="relative aspect-video w-full overflow-hidden bg-slate-900">
                  <Image
                    src={thumbUrl}
                    alt={video.title}
                    fill
                    className="object-cover group-hover:scale-105 transition-transform duration-500"
                    sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 25vw"
                    onError={() => {
                      if (!hasError) {
                        setImgErrors((prev) => ({ ...prev, [video.id]: true }));
                      }
                    }}
                  />

                  {/* Category Pill */}
                  <div className="absolute top-3 left-3 z-10">
                    <span className="bg-slate-900/80 backdrop-blur-sm text-white text-[10px] font-bold px-2.5 py-1 rounded-full border border-white/20">
                      {video.category}
                    </span>
                  </div>

                  {/* Play Button Overlay */}
                  <div className="absolute inset-0 bg-black/30 group-hover:bg-black/10 transition-colors flex items-center justify-center">
                    <div className="w-12 h-12 rounded-full bg-teal-500 group-hover:bg-teal-400 text-white flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform">
                      <Play className="w-5 h-5 ml-0.5 fill-white" />
                    </div>
                  </div>
                </div>

                {/* Content info */}
                <div className="p-5 flex-1 flex flex-col justify-between">
                  <div>
                    <h3 className="font-bold text-black dark:text-white text-sm sm:text-base line-clamp-2 group-hover:text-teal-600 dark:group-hover:text-teal-400 transition-colors mb-2">
                      {video.title}
                    </h3>
                    <p className="text-xs text-black dark:text-slate-400 line-clamp-2 leading-relaxed">
                      {video.description}
                    </p>
                  </div>
                  <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-700/60 flex items-center gap-1.5 text-xs font-semibold text-teal-600 dark:text-teal-400">
                    <Film className="w-3.5 h-3.5" />
                    <span>Putar Video</span>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </motion.div>

      {/* Video Modal */}
      <VideoModal video={activeVideo} onClose={() => setActiveVideo(null)} />
    </div>
  );
}
