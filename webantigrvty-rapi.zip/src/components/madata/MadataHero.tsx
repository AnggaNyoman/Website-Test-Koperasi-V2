"use client";

import Image from "next/image";
import { useEffect, useState } from "react";
import { SITE_CONFIG } from "@/lib/constants";
import { Star, ShieldCheck } from "lucide-react";

export default function MadataHero() {
  const [os, setOs] = useState<"android" | "ios" | "other">("other");
  const [slide, setSlide] = useState(0);
  const screens = [
    "/app/screens/screen-1.png",
    "/app/screens/screen-2.png",
    "/app/screens/screen-3.png",
    "/app/screens/screen-4.png",
    "/app/screens/screen-5.png",
    "/app/screens/screen-6.png",
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setSlide((prev) => (prev + 1) % screens.length);
    }, 3200);
    return () => clearInterval(timer);
  }, [screens.length]);

  useEffect(() => {
    const userAgent = navigator.userAgent || navigator.vendor;
    if (/android/i.test(userAgent)) {
      setOs("android");
    } else if (/iPad|iPhone|iPod/.test(userAgent)) {
      setOs("ios");
    }
  }, []);

  return (
    <div className="relative overflow-hidden bg-gradient-to-br from-teal-900 via-teal-800 to-cyan-900 text-white py-16 sm:py-24 px-4 sm:px-6 lg:px-8">
<div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-12 items-center relative z-10">
        {/* Left Column: Text & CTAs */}
        <div className="lg:col-span-7 text-center lg:text-left">
          {/* Smart OS Badge */}
          {os === "android" && (
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-500/20 border border-emerald-400/40 text-emerald-300 text-xs font-semibold mb-6">
              <span>Perangkat Android Terdeteksi — Tersedia di Google Play</span>
            </div>
          )}
          {os === "ios" && (
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-500/20 border border-blue-400/40 text-blue-200 text-xs font-semibold mb-6">
              <span>Perangkat iOS Terdeteksi — Versi iOS Segera Hadir</span>
            </div>
          )}

          <div className="flex items-center justify-center lg:justify-start gap-3 mb-4">
            <div className="w-12 h-12 relative rounded-xl overflow-hidden shadow-lg border border-white/20 bg-white p-1">
              <Image
                src="/madata-logo.png"
                alt="Madata Mobile Logo"
                fill
                className="object-contain"
              />
            </div>
            <span className="text-sm uppercase tracking-widest font-bold text-cyan-300">
              Aplikasi Mobile Banking Resmi
            </span>
          </div>

          <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight mb-4 leading-tight">
            Madata Mobile <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-300 via-teal-200 to-emerald-300">
              Koperasi Dalam Genggaman
            </span>
          </h1>

          <p className="text-teal-100 text-base sm:text-lg max-w-xl mx-auto lg:mx-0 mb-8 leading-relaxed">
            Akses seluruh layanan simpan pinjam Koperasi Mandara Sedana Kuta kapan pun dan di mana pun. Cek saldo, transfer, bayar tagihan PPOB hingga pembelian pulsa dalam satu aplikasi praktis.
          </p>

          {/* Download Buttons */}
          <div className="flex flex-wrap items-center justify-center lg:justify-start gap-4 mb-8">
            <a
              href={SITE_CONFIG.googlePlayUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block transition-transform hover:-translate-y-0.5"
            >
              <img
                src="/badges/google-play-badge.svg"
                alt="Unduh di Google Play"
                className="h-12 sm:h-14 w-auto"
              />
            </a>

            <div className="relative inline-block opacity-50 cursor-not-allowed">
              <img
                src="/badges/app-store-badge.svg"
                alt="Segera hadir di App Store"
                className="h-12 sm:h-14 w-auto grayscale"
              />
              <span className="absolute -top-2 -right-2 bg-amber-500 text-slate-900 text-[9px] font-bold px-1.5 py-0.5 rounded-full shadow">
                Segera
              </span>
            </div>
          </div>

          <div className="flex items-center justify-center lg:justify-start gap-6 text-xs text-teal-200">
            <div className="flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Aman & Terenkripsi</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
              <span>Rating 4.8 di Play Store</span>
            </div>
          </div>
        </div>

        {/* Right Column: Mobile App Screenshot Slider */}
        <div className="lg:col-span-5 flex justify-center">
          <div className="relative w-64 sm:w-80 aspect-[9/17]">
            {screens.map((src, i) => (
              <div
                key={src}
                className={`absolute inset-0 flex items-center justify-center transition-opacity duration-700 ${
                  i === slide ? "opacity-100" : "opacity-0"
                }`}
              >
                <div className="relative w-full h-full">
                  <Image
                    src={src}
                    alt="Tampilan layar aplikasi Madata Mobile"
                    fill
                    className="object-contain drop-shadow-2xl"
                    sizes="(max-width: 640px) 256px, 320px"
                    priority={i === 0}
                  />
                </div>
              </div>
            ))}

            {/* Slide indicators */}
            <div className="absolute -bottom-7 left-0 right-0 flex items-center justify-center gap-1.5">
              {screens.map((_, i) => (
                <button
                  key={i}
                  onClick={() => setSlide(i)}
                  aria-label={`Tampilkan layar ${i + 1}`}
                  className={`h-1.5 rounded-full transition-all ${
                    i === slide ? "w-5 bg-white" : "w-1.5 bg-white/40"
                  }`}
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
