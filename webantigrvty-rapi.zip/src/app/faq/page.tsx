"use client";

import { useState } from "react";
import { FAQ_DATA } from "@/lib/constants";
import Breadcrumb from "@/components/ui/Breadcrumb";
import SectionBadge from "@/components/ui/SectionBadge";
import { ChevronDown, Search, HelpCircle, MessageCircle } from "lucide-react";
import { WHATSAPP_URL } from "@/lib/constants";
const CATEGORIES = ["Semua", "Anggota", "Simpanan", "Pinjaman", "Madata Mobile", "SHU", "Umum"];

export default function FAQPage() {
  const [selectedCat, setSelectedCat] = useState("Semua");
  const [searchQuery, setSearchQuery] = useState("");
  const [openId, setOpenId] = useState<string | null>("faq1");

  const filteredFaqs = FAQ_DATA.filter((item) => {
    const matchesCat = selectedCat === "Semua" || item.category === selectedCat;
    const matchesSearch =
      item.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.answer.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  return (
    <div className="min-h-screen">
      {/* Header Banner */}
      <div className="bg-gradient-to-br from-teal-800 via-teal-900 to-slate-900 py-16 px-4 text-center relative overflow-hidden">
<div className="relative z-10 max-w-4xl mx-auto">
          <SectionBadge variant="teal">
            Pusat Bantuan & Informasi
          </SectionBadge>
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-white mb-4 tracking-tight">
            Pertanyaan Yang Sering Diajukan (FAQ)
          </h1>
          <p className="text-teal-200 text-base md:text-lg max-w-2xl mx-auto">
            Temukan jawaban lengkap seputar keanggotaan, produk simpanan, pengajuan pinjaman, aplikasi Madata Mobile, hingga pembagian SHU.
          </p>
        </div>
      </div>

      {/* Breadcrumb Bar */}
      <div className="bg-slate-100 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-800 py-3 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <Breadcrumb items={[{ label: "FAQ" }]} />
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-5xl mx-auto py-16 px-4 sm:px-6 lg:px-8">
        {/* Search Bar */}
        <div className="relative max-w-xl mx-auto mb-8">
          <Search className="w-5 h-5 text-black absolute left-4 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Cari pertanyaan... (contoh: bunga, syarat pinjaman, login)"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-12 pr-4 py-3.5 rounded-2xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-sm focus:outline-none focus:ring-2 focus:ring-teal-500 text-sm text-black dark:text-white"
          />
        </div>

        {/* Category Pills */}
        <div className="flex flex-wrap justify-center gap-2 mb-12">
          {CATEGORIES.map((cat) => {
            const isActive = selectedCat === cat;
            return (
              <button
                key={cat}
                onClick={() => setSelectedCat(cat)}
                className={`px-4 py-2 rounded-full text-xs sm:text-sm font-bold transition-all ${
                  isActive
                    ? "bg-teal-600 text-white shadow-md"
                    : "bg-white dark:bg-slate-800 text-black dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:border-teal-500"
                }`}
              >
                {cat}
              </button>
            );
          })}
        </div>

        {/* FAQ Accordion List */}
        <div className="space-y-4 mb-16">
          {filteredFaqs.length > 0 ? (
            filteredFaqs.map((faq) => {
              const isOpen = openId === faq.id;
              return (
                <div
                  key={faq.id}
                  className="rounded-2xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 shadow-sm overflow-hidden transition-all"
                >
                  <button
                    type="button"
                    onClick={() => setOpenId(isOpen ? null : faq.id)}
                    className="w-full flex items-center justify-between p-6 text-left font-bold text-sm sm:text-base text-black dark:text-white hover:text-teal-600 dark:hover:text-teal-400 transition-colors"
                  >
                    <span className="flex items-center gap-3 pr-4">
                      <span className="text-xs font-semibold px-2.5 py-1 rounded-lg bg-teal-50 dark:bg-teal-950/60 text-teal-700 dark:text-teal-300 shrink-0">
                        {faq.category}
                      </span>
                      <span>{faq.question}</span>
                    </span>
                    <ChevronDown
                      className={`w-5 h-5 text-black transform transition-transform shrink-0 ${
                        isOpen ? "rotate-180 text-teal-600" : ""
                      }`}
                    />
                  </button>
                  {isOpen && (
                    <div className="px-6 pb-6 pt-2 text-xs sm:text-sm text-black dark:text-slate-300 leading-relaxed border-t border-slate-100 dark:border-slate-700/60 bg-slate-50/50 dark:bg-slate-900/30">
                      {faq.answer}
                    </div>
                  )}
                </div>
              );
            })
          ) : (
            <div className="text-center py-12 bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700">
              <HelpCircle className="w-12 h-12 text-slate-300 mx-auto mb-3" />
              <p className="text-black dark:text-slate-400 text-sm font-medium">
                Tidak ada pertanyaan yang sesuai dengan kata kunci pencarian Anda.
              </p>
            </div>
          )}
        </div>

        {/* Still have questions CTA */}
        <div className="rounded-3xl p-8 bg-gradient-to-r from-teal-800 to-cyan-900 text-white flex flex-col md:flex-row items-center justify-between gap-6 shadow-xl text-center md:text-left">
          <div>
            <h3 className="text-xl font-bold mb-1">Masih Memiliki Pertanyaan Lain?</h3>
            <p className="text-teal-200 text-xs sm:text-sm">
              Tim layanan pelanggan kami siap membantu Anda setiap hari kerja melalui WhatsApp atau telepon.
            </p>
          </div>
          <a
            href={WHATSAPP_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="shrink-0 inline-flex items-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-white font-bold px-6 py-3 rounded-2xl shadow-lg transition-all text-sm"
          >
            <MessageCircle className="w-4 h-4" />
            <span>Chat WhatsApp CS</span>
          </a>
        </div>
      </div>

</div>
  );
}
