"use client";

import { useState } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import { Wallet, PiggyBank, Coins, Clock, Briefcase, CreditCard, GraduationCap, Zap, ArrowRight, CheckCircle2, Calculator, ShieldAlert, Smartphone, Droplet, ArrowLeftRight, Phone, HeartPulse } from "lucide-react";
import Breadcrumb from "@/components/ui/Breadcrumb";
import SectionBadge from "@/components/ui/SectionBadge";

import { SERVICES, PPOB_SERVICES } from "@/lib/constants";
import { LucideIcon } from "lucide-react";
const iconMap: Record<string, LucideIcon> = {
  Wallet,
  PiggyBank,
  Coins,
  Clock,
  Briefcase,
  CreditCard,
  GraduationCap,
  Zap,
};
const ppobIconMap: Record<string, LucideIcon> = {
  Wallet,
  Zap,
  Smartphone,
  Droplet,
  CreditCard,
  ArrowLeftRight,
  Phone,
  HeartPulse,
};

export default function LayananPage() {
  const [filter, setFilter] = useState<"all" | "simpanan" | "pinjaman">("all");

  const filteredServices = SERVICES.filter((s) => {
    if (filter === "all") return true;
    return s.category === filter;
  });

  return (
    <div className="min-h-screen">
      {/* Header Banner */}
      <div className="bg-gradient-to-br from-teal-800 via-teal-900 to-slate-900 py-16 px-4 text-center relative overflow-hidden">
<div className="relative z-10 max-w-4xl mx-auto">
          <SectionBadge variant="cyan">
            Produk & Layanan Keuangan
          </SectionBadge>
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-white mb-4 tracking-tight">
            Layanan Keuangan Terpercaya
          </h1>
          <p className="text-teal-200 text-base md:text-lg max-w-2xl mx-auto">
            Solusi simpanan aman dan pembiayaan terjangkau yang dirancang khusus untuk memajukan perekonomian krama Bali.
          </p>
        </div>
      </div>

      {/* Breadcrumb Bar */}
      <div className="bg-slate-100 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-800 py-3 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <Breadcrumb items={[{ label: "Layanan" }]} />
        </div>
      </div>

      {/* Main Content Area */}
      <div className="max-w-7xl mx-auto py-16 px-4 sm:px-6 lg:px-8">
        {/* Category Filter Pills */}
        <div className="flex justify-center gap-3 mb-12">
          <button
            onClick={() => setFilter("all")}
            className={`px-5 py-2.5 rounded-full text-sm font-bold transition-all shadow-sm ${
              filter === "all"
                ? "bg-teal-600 text-white shadow-teal-500/25 shadow-md"
                : "bg-white dark:bg-slate-800 text-black dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:border-teal-500"
            }`}
          >
            Semua Layanan (8)
          </button>
          <button
            onClick={() => setFilter("simpanan")}
            className={`px-5 py-2.5 rounded-full text-sm font-bold transition-all shadow-sm ${
              filter === "simpanan"
                ? "bg-teal-600 text-white shadow-teal-500/25 shadow-md"
                : "bg-white dark:bg-slate-800 text-black dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:border-teal-500"
            }`}
          >
            Produk Simpanan (4)
          </button>
          <button
            onClick={() => setFilter("pinjaman")}
            className={`px-5 py-2.5 rounded-full text-sm font-bold transition-all shadow-sm ${
              filter === "pinjaman"
                ? "bg-teal-600 text-white shadow-teal-500/25 shadow-md"
                : "bg-white dark:bg-slate-800 text-black dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:border-teal-500"
            }`}
          >
            Produk Pinjaman (4)
          </button>
        </div>

        {/* Services Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {filteredServices.map((svc) => {
            const Icon = iconMap[svc.icon] || Wallet;
            const isSimpanan = svc.category === "simpanan";
            return (
              <motion.div
                key={svc.id}
                layout
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ duration: 0.3 }}
                className="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700/80 shadow-md hover:shadow-xl transition-all duration-300 flex flex-col justify-between overflow-hidden group relative"
              >
                <div className={`h-1.5 w-full bg-gradient-to-r ${svc.color}`} />
<div className="p-6">
                  {/* Category Tag */}
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-12 h-12 rounded-xl bg-teal-50 dark:bg-teal-950/60 text-teal-600 dark:text-teal-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                      <Icon className="w-6 h-6" />
                    </div>
                    <span
                      className={`text-[10px] uppercase font-bold tracking-wider px-2.5 py-1 rounded-full ${
                        isSimpanan
                          ? "bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300"
                          : "bg-cyan-50 dark:bg-cyan-950/60 text-cyan-700 dark:text-cyan-300"
                      }`}
                    >
                      {isSimpanan ? "Simpanan" : "Pinjaman"}
                    </span>
                  </div>

                  <h3 className="text-lg font-bold text-black dark:text-white mb-2 group-hover:text-teal-600 dark:group-hover:text-teal-400 transition-colors">
                    {svc.title}
                  </h3>
                  <p className="text-black dark:text-slate-300 text-xs sm:text-sm leading-relaxed mb-4">
                    {svc.description}
                  </p>
                </div>

                <div className="p-6 pt-0 border-t border-slate-100 dark:border-slate-700/60 mt-auto">
                  <div className="flex items-center justify-between pt-4">
                    <Link
                      href={isSimpanan ? "/simulasi#simpanan" : "/simulasi#pinjaman"}
                      className="text-xs font-semibold text-teal-600 dark:text-teal-400 hover:underline flex items-center gap-1"
                    >
                      <Calculator className="w-3.5 h-3.5" /> Hitung Simulasi
                    </Link>
                    <Link
                      href="/daftar-anggota"
                      className="inline-flex items-center gap-1 text-xs font-bold bg-slate-100 dark:bg-slate-700 hover:bg-teal-600 hover:text-white text-black dark:text-slate-200 px-3 py-1.5 rounded-lg transition-colors"
                    >
                      Daftar <ArrowRight className="w-3 h-3" />
                    </Link>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Benefits & Guarantees Strip */}
        <div className="rounded-2xl bg-gradient-to-r from-teal-50 to-cyan-50 dark:from-slate-800/80 dark:to-slate-900/80 p-8 border border-teal-100 dark:border-slate-700 mb-16">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-xl bg-teal-600 text-white flex items-center justify-center shrink-0 shadow-md">
                <CheckCircle2 className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-bold text-black dark:text-white text-sm sm:text-base mb-1">
                  Bunga Kompetitif & Transparan
                </h4>
                <p className="text-black dark:text-slate-300 text-xs leading-relaxed">
                  Tidak ada biaya tersembunyi. Perhitungan bunga simpanan dan pinjaman diinformasikan jelas sejak awal.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-xl bg-cyan-600 text-white flex items-center justify-center shrink-0 shadow-md">
                <Calculator className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-bold text-black dark:text-white text-sm sm:text-base mb-1">
                  Proses Cepat & Persyaratan Mudah
                </h4>
                <p className="text-black dark:text-slate-300 text-xs leading-relaxed">
                  Cukup KTP, KK, dan keanggotaan aktif. Tim kami siap mendampingi proses hingga dana cair.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="w-10 h-10 rounded-xl bg-primary-600 text-white flex items-center justify-center shrink-0 shadow-md">
                <ShieldAlert className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-bold text-black dark:text-white text-sm sm:text-base mb-1">
                  Hak SHU Tahunan
                </h4>
                <p className="text-black dark:text-slate-300 text-xs leading-relaxed">
                  Setiap simpanan dan pinjaman anggota turut berkontribusi pada penerimaan Sisa Hasil Usaha setiap tahunnya.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* PPOB & Digital Transaction Services */}
        <div className="mb-16">
          <div className="text-center max-w-2xl mx-auto mb-10">
            <SectionBadge variant="cyan">Layanan Transaksi Digital</SectionBadge>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-black dark:text-white tracking-tight mt-3">
              Semua Kebutuhan Transaksi dalam Satu Aplikasi
            </h2>
            <p className="text-black dark:text-slate-300 text-sm sm:text-base mt-2">
              Selain simpan pinjam, nikmati juga berbagai layanan pembayaran melalui Madata Mobile atau kantor koperasi.
            </p>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {PPOB_SERVICES.map((item, idx) => {
              const Icon = ppobIconMap[item.icon] || Wallet;
              return (
                <div
                  key={idx}
                  className="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:border-teal-400 hover:shadow-lg transition-all rounded-2xl p-4 flex flex-col items-start gap-3"
                >
                  <div className="w-10 h-10 rounded-xl bg-teal-50 dark:bg-teal-900/50 text-teal-600 dark:text-teal-400 flex items-center justify-center shrink-0">
                    <Icon className="w-5 h-5" />
                  </div>
                  <span className="text-sm font-bold leading-tight text-black dark:text-white">{item.title}</span>
                </div>
              );
            })}
          </div>
          <div className="text-center mt-8">
            <Link
              href="/madata-mobile"
              className="inline-flex items-center gap-2 bg-primary-500 hover:bg-primary-400 text-slate-900 font-bold px-6 py-3 rounded-xl shadow-lg transition-all active:scale-95"
            >
              <Smartphone className="w-4 h-4" />
              Unduh Madata Mobile
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>

        {/* CTA Banner */}
        <div className="text-center bg-gradient-to-r from-teal-800 to-teal-900 text-white p-10 rounded-2xl shadow-xl relative overflow-hidden">
          <div className="relative z-10 max-w-2xl mx-auto">
            <h3 className="text-2xl sm:text-3xl font-bold mb-3">
              Ingin Mengetahui Rincian & Tabel Tarif?
            </h3>
            <p className="text-teal-200 text-sm mb-6">
              Bandingkan semua produk simpanan dan pinjaman kami secara detail di halaman tabel produk.
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Link
                href="/produk"
                className="bg-white text-teal-900 hover:bg-teal-50 font-bold px-6 py-3 rounded-xl shadow-lg transition-all"
              >
                Lihat Tabel Produk Lengkap
              </Link>
              <Link
                href="/simulasi"
                className="bg-teal-700/80 hover:bg-teal-600 text-white border border-teal-500 font-bold px-6 py-3 rounded-xl transition-all"
              >
                Kalkulator Simulasi Pinjaman
              </Link>
              <Link
                href="/madata-mobile"
                className="bg-primary-500 hover:bg-primary-400 text-slate-900 font-bold px-6 py-3 rounded-xl shadow-lg transition-all flex items-center gap-2"
              >
                <Smartphone className="w-4 h-4" />
                Madata Mobile
              </Link>
            </div>
          </div>
        </div>
      </div>
</div>
  );
}
