import type { Metadata } from "next";
import VideoGallery from "@/components/gallery/VideoGallery";
import Breadcrumb from "@/components/ui/Breadcrumb";
import SectionBadge from "@/components/ui/SectionBadge";

export const metadata: Metadata = {
  title: "Galeri Video | Koperasi Mandara Sedana Kuta",
  description:
    "Tonton dokumentasi kegiatan, profil koperasi, podcast keuangan, dan bakti sosial Koperasi Mandara Sedana Kuta di Pulau Bali.",
};

export default function GaleriPage() {
  return (
    <div className="min-h-screen">
      {/* Header Banner */}
      <div className="bg-gradient-to-br from-teal-800 via-teal-900 to-slate-900 py-16 px-4 text-center relative overflow-hidden">
<div className="relative z-10 max-w-4xl mx-auto">
          <SectionBadge variant="cyan">
            Dokumentasi & Media
          </SectionBadge>
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-white mb-4 tracking-tight">
            Galeri Video Koperasi
          </h1>
          <p className="text-teal-200 text-base md:text-lg max-w-2xl mx-auto">
            Saksikan ragam kegiatan, komitmen pelayanan, edukasi finansial, dan kebersamaan komunitas anggota kami di Bali.
          </p>
        </div>
      </div>

      {/* Breadcrumb Bar */}
      <div className="bg-slate-100 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-800 py-3 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <Breadcrumb items={[{ label: "Galeri" }]} />
        </div>
      </div>

      {/* Gallery Content */}
      <div className="max-w-7xl mx-auto py-16 px-4 sm:px-6 lg:px-8">
        <VideoGallery />
      </div>

</div>
  );
}
