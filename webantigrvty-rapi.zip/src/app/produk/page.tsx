"use client";

import { useState } from "react";
import Link from "next/link";
import SimpananTable from "@/components/products/SimpananTable";
import PinjamanTable from "@/components/products/PinjamanTable";
import Breadcrumb from "@/components/ui/Breadcrumb";
import SectionBadge from "@/components/ui/SectionBadge";

import { PiggyBank, HandCoins, FileCheck2, AlertCircle, Calculator, UserPlus } from "lucide-react";
export default function ProdukPage() {
  const [activeTab, setActiveTab] = useState<"simpanan" | "pinjaman">("simpanan");

  return (
    <div className="min-h-screen">
      {/* Header Banner */}
      <div className="bg-gradient-to-br from-teal-800 via-teal-900 to-slate-900 py-16 px-4 text-center relative overflow-hidden">
<div className="relative z-10 max-w-4xl mx-auto">
          <SectionBadge variant="teal">
            Rincian Tarif & Produk
          </SectionBadge>
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-white mb-4 tracking-tight">
            Katalog Produk Simpan Pinjam
          </h1>
          <p className="text-teal-200 text-base md:text-lg max-w-2xl mx-auto">
            Informasi lengkap dan transparan mengenai suku bunga, plafon, jangka waktu, dan ketentuan simpanan serta pinjaman Koperasi Mandara Sedana Kuta.
          </p>
        </div>
      </div>

      {/* Breadcrumb Bar */}
      <div className="bg-slate-100 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-800 py-3 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <Breadcrumb items={[{ label: "Produk" }]} />
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto py-16 px-4 sm:px-6 lg:px-8">
        {/* Navigation Tabs */}
        <div className="flex justify-center mb-10">
          <div className="inline-flex p-1.5 rounded-2xl bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-inner">
            <button
              onClick={() => setActiveTab("simpanan")}
              className={`flex items-center gap-2 px-6 py-3 rounded-xl font-bold text-sm transition-all ${
                activeTab === "simpanan"
                  ? "bg-white dark:bg-slate-700 text-teal-700 dark:text-teal-300 shadow-md scale-102"
                  : "text-black dark:text-slate-400 hover:text-black dark:hover:text-white"
              }`}
            >
              <PiggyBank className="w-4 h-4" />
              <span>Tabel Produk Simpanan</span>
            </button>
            <button
              onClick={() => setActiveTab("pinjaman")}
              className={`flex items-center gap-2 px-6 py-3 rounded-xl font-bold text-sm transition-all ${
                activeTab === "pinjaman"
                  ? "bg-white dark:bg-slate-700 text-cyan-700 dark:text-cyan-300 shadow-md scale-102"
                  : "text-black dark:text-slate-400 hover:text-black dark:hover:text-white"
              }`}
            >
              <HandCoins className="w-4 h-4" />
              <span>Tabel Produk Pinjaman</span>
            </button>
          </div>
        </div>

        {/* Tab Content */}
        <div className="mb-16">
          {activeTab === "simpanan" ? (
            <div>
              <div className="mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h2 className="text-2xl font-bold text-black dark:text-white">
                    Pilihan Produk Simpanan
                  </h2>
                  <p className="text-sm text-black dark:text-slate-400">
                    Mulai dari simpanan wajib berkala hingga deposito berjangka dengan bunga hingga 8,47%/tahun.
                  </p>
                </div>
                <Link
                  href="/simulasi#simpanan"
                  className="inline-flex items-center gap-2 text-xs sm:text-sm font-bold text-teal-600 dark:text-teal-400 bg-teal-50 dark:bg-teal-950/60 px-4 py-2 rounded-xl border border-teal-200 dark:border-teal-800 hover:bg-teal-100"
                >
                  <Calculator className="w-4 h-4" /> Simulasi Hasil Simpanan
                </Link>
              </div>
              <SimpananTable />
            </div>
          ) : (
            <div>
              <div className="mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <h2 className="text-2xl font-bold text-black dark:text-white">
                    Pilihan Produk Pembiayaan (Pinjaman)
                  </h2>
                  <p className="text-sm text-black dark:text-slate-400">
                    Bunga kompetitif mulai 1% per bulan dengan tenor fleksibel hingga 10 tahun sesuai jenis pinjaman.
                  </p>
                </div>
                <Link
                  href="/simulasi#pinjaman"
                  className="inline-flex items-center gap-2 text-xs sm:text-sm font-bold text-cyan-600 dark:text-cyan-400 bg-cyan-50 dark:bg-cyan-950/60 px-4 py-2 rounded-xl border border-cyan-200 dark:border-cyan-800 hover:bg-cyan-100"
                >
                  <Calculator className="w-4 h-4" /> Kalkulator Angsuran
                </Link>
              </div>
              <PinjamanTable />
            </div>
          )}
        </div>

        {/* Biaya & Ketentuan Penting Card */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          <div className="bg-white dark:bg-slate-800 rounded-2xl p-6 sm:p-8 border border-slate-200 dark:border-slate-700 shadow-sm relative">
<div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-teal-50 dark:bg-teal-950/60 text-teal-600 dark:text-teal-400 flex items-center justify-center">
                <FileCheck2 className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-bold text-black dark:text-white">
                Syarat & Ketentuan Umum
              </h3>
            </div>
            <ul className="space-y-3 text-xs sm:text-sm text-black dark:text-slate-300">
              <li className="flex items-start gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-teal-500 mt-2 shrink-0" />
                <span>Pemohon wajib terdaftar sebagai anggota aktif Koperasi Mandara Sedana Kuta.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-teal-500 mt-2 shrink-0" />
                <span>Melampirkan fotokopi KTP elektronik dan Kartu Keluarga (KK) yang masih berlaku.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-teal-500 mt-2 shrink-0" />
                <span>Telah melunasi Simpanan Pokok (Rp 10.000) dan Simpanan Wajib (Rp 10.000) sesuai klasifikasi anggota.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-teal-500 mt-2 shrink-0" />
                <span>Untuk pinjaman modal usaha, menyertakan bukti usaha atau profil kegiatan usaha di Bali.</span>
              </li>
            </ul>
          </div>

          <div className="bg-white dark:bg-slate-800 rounded-2xl p-6 sm:p-8 border border-slate-200 dark:border-slate-700 shadow-sm relative">
<div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-cyan-50 dark:bg-cyan-950/60 text-cyan-600 dark:text-cyan-400 flex items-center justify-center">
                <AlertCircle className="w-5 h-5" />
              </div>
              <h3 className="text-lg font-bold text-black dark:text-white">
                Rincian Biaya Pinjaman
              </h3>
            </div>
            <div className="space-y-3 text-xs sm:text-sm">
              <div className="flex justify-between items-center py-2 border-b border-slate-100 dark:border-slate-700/60">
                <span className="text-black dark:text-slate-400">Biaya Administrasi</span>
                <span className="font-bold text-black dark:text-white font-mono">1% – 2% (sesuai tenor)</span>
              </div>
              <div className="flex justify-between items-center py-2 border-b border-slate-100 dark:border-slate-700/60">
                <span className="text-black dark:text-slate-400">Biaya Provisi</span>
                <span className="font-bold text-black dark:text-white font-mono">0,5% dari plafon</span>
              </div>
              <div className="flex justify-between items-center py-2 border-b border-slate-100 dark:border-slate-700/60">
                <span className="text-black dark:text-slate-400">Denda Keterlambatan</span>
                <span className="font-bold text-amber-600 dark:text-amber-400 font-mono">0,1% / hari keterlambatan</span>
              </div>
              <div className="flex justify-between items-center py-2">
                <span className="text-black dark:text-slate-400">Pelunasan Dipercepat</span>
                <span className="font-bold text-emerald-600 dark:text-emerald-400">Tanpa Penalti</span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom CTA */}
        <div className="rounded-2xl p-8 bg-gradient-to-r from-teal-800 to-cyan-900 text-white flex flex-col md:flex-row items-center justify-between gap-6 shadow-xl">
          <div>
            <h3 className="text-xl font-bold mb-1">Belum Menjadi Anggota?</h3>
            <p className="text-teal-200 text-xs sm:text-sm">
              Daftar online sekarang untuk menikmati seluruh produk simpanan berbunga menarik dan pinjaman modal usaha.
            </p>
          </div>
          <Link
            href="/daftar-anggota"
            className="shrink-0 flex items-center gap-2 bg-white text-teal-900 hover:bg-teal-50 font-bold px-6 py-3 rounded-xl shadow-lg transition-all text-sm"
          >
            <UserPlus className="w-4 h-4 text-teal-700" />
            <span>Formulir Pendaftaran</span>
          </Link>
        </div>
      </div>
</div>
  );
}
