import type { Metadata } from "next";
import VisiMisi from "@/components/about/VisiMisi";
import VideoProfile from "@/components/about/VideoProfile";
import KerenValues from "@/components/about/KerenValues";
import StrukturOrganisasi from "@/components/about/StrukturOrganisasi";
import LegalitasSection from "@/components/about/LegalitasSection";
import SejarahTimeline from "@/components/about/SejarahTimeline";

export const metadata: Metadata = {
  title: "Tentang Kami",
  description:
    "Mengenal lebih dekat Koperasi Mandara Sedana Kuta — visi, misi, nilai KEREN, struktur organisasi, dan sejarah perkembangan koperasi kami.",
};

export default function TentangKamiPage() {
  return (
    <div className="min-h-screen">
      {/* Page Header */}
      <div className="bg-gradient-to-br from-teal-800 to-teal-900 py-16 px-4 text-center relative overflow-hidden">
<div className="relative z-10 max-w-3xl mx-auto">
          <span className="badge bg-white/10 text-white/80 border border-white/20 mb-4 inline-flex">
            Profil Koperasi
          </span>
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold text-white mb-3">
            Tentang Kami
          </h1>
          <p className="text-teal-200 text-base md:text-lg">
            Mengenal lebih dekat Koperasi Mandara Sedana Kuta — mitra keuangan terpercaya Anda di Bali.
          </p>
        </div>
      </div>

      {/* Sections */}
      <VisiMisi />
<VideoProfile />
<KerenValues />
<StrukturOrganisasi />
<LegalitasSection />
<SejarahTimeline />
    </div>
  );
}
