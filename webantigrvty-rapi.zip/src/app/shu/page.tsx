import type { Metadata } from "next";
import SHUChart from "@/components/shu/SHUChart";
import Breadcrumb from "@/components/ui/Breadcrumb";
import SectionBadge from "@/components/ui/SectionBadge";

import { Calendar, DollarSign, Award, ShieldCheck, ArrowRight } from "lucide-react";
import Link from "next/link";

export const metadata: Metadata = {
  title: "Sisa Hasil Usaha (SHU) | Koperasi Mandara Sedana Kuta",
  description:
    "Pelajari pembagian Sisa Hasil Usaha (SHU) Koperasi Mandara Sedana Kuta dengan rata-rata 8% per tahun yang dibagikan setiap bulan Januari secara transparan.",
};

export default function SHUPage() {
  return (
    <div className="min-h-screen">
      {/* Header Banner */}
      <div className="bg-gradient-to-br from-teal-800 via-teal-900 to-slate-900 py-16 px-4 text-center relative overflow-hidden">
<div className="relative z-10 max-w-4xl mx-auto">
          <SectionBadge variant="gold">
            Keuntungan Bersama Anggota
          </SectionBadge>
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-white mb-4 tracking-tight">
            Sisa Hasil Usaha (SHU)
          </h1>
          <p className="text-teal-200 text-base md:text-lg max-w-2xl mx-auto">
            Wujud nyata asas kekeluargaan dan gotong royong koperasi — keuntungan usaha dikembalikan seutuhnya untuk kemakmuran para anggota.
          </p>
        </div>
      </div>

      {/* Breadcrumb Bar */}
      <div className="bg-slate-100 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-800 py-3 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <Breadcrumb items={[{ label: "SHU" }]} />
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto py-16 px-4 sm:px-6 lg:px-8">
        {/* Highlight 3 Metric Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
          <div className="bg-white dark:bg-slate-800 rounded-2xl p-6 border border-slate-200 dark:border-slate-700 shadow-md relative overflow-hidden">
<div className="w-12 h-12 rounded-xl bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 flex items-center justify-center mb-4">
              <DollarSign className="w-6 h-6" />
            </div>
            <span className="text-xs uppercase font-bold tracking-wider text-black">
              Capaian SHU Tahun Lalu
            </span>
            <div className="text-4xl font-extrabold text-black dark:text-white font-mono mt-1">
              8% <span className="text-sm font-sans font-medium text-black">/ tahun</span>
            </div>
            <p className="text-xs text-black mt-2">
              Tingkat pengembalian kompetitif di atas suku bunga rata-rata deposito perbankan.
            </p>
          </div>

          <div className="bg-white dark:bg-slate-800 rounded-2xl p-6 border border-slate-200 dark:border-slate-700 shadow-md relative overflow-hidden">
<div className="w-12 h-12 rounded-xl bg-cyan-50 dark:bg-cyan-950/60 text-cyan-600 dark:text-cyan-400 flex items-center justify-center mb-4">
              <Calendar className="w-6 h-6" />
            </div>
            <span className="text-xs uppercase font-bold tracking-wider text-black">
              Jadwal Pencairan
            </span>
            <div className="text-4xl font-extrabold text-black dark:text-white mt-1">
              Januari
            </div>
            <p className="text-xs text-black mt-2">
              Dibagikan setiap bulan Januari setelah Rapat Anggota Tahunan (RAT) tutup buku.
            </p>
          </div>

          <div className="bg-white dark:bg-slate-800 rounded-2xl p-6 border border-slate-200 dark:border-slate-700 shadow-md relative overflow-hidden">
<div className="w-12 h-12 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mb-4">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <span className="text-xs uppercase font-bold tracking-wider text-black">
              Audit & Transparansi
            </span>
            <div className="text-4xl font-extrabold text-black dark:text-white mt-1">
              100%
            </div>
            <p className="text-xs text-black mt-2">
              Laporan keuangan diaudit dan disampaikan transparan kepada seluruh anggota.
            </p>
          </div>
        </div>

        {/* Recharts Pie Chart & Simulator Section */}
        <div className="mb-16">
          <div className="text-center max-w-3xl mx-auto mb-12">
            <h2 className="text-2xl sm:text-3xl font-bold text-black dark:text-white mb-3">
              Mekanisme & Formula Pembagian SHU
            </h2>
            <p className="text-sm text-black dark:text-slate-300">
              Koperasi Mandara Sedana Kuta membagi SHU secara proporsional sesuai kontribusi masing-masing anggota.
            </p>
          </div>
          <SHUChart />
        </div>

        {/* Apa Itu SHU Explanation Bento */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          <div className="bg-white dark:bg-slate-800 rounded-2xl p-6 sm:p-8 border border-slate-200 dark:border-slate-700 shadow-sm relative">
<h3 className="text-xl font-bold text-black dark:text-white mb-4">
              Bagaimana Cara Memperoleh SHU yang Maksimal?
            </h3>
            <ul className="space-y-3 text-xs sm:text-sm text-black dark:text-slate-300">
              <li className="flex items-start gap-2">
                <Award className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
                <span><strong>Tingkatkan Saldo Simpanan:</strong> Rutin menabung Simpanan Wajib dan simpanan sukarela/berjangka memperbesar porsi jasa modal Anda.</span>
              </li>
              <li className="flex items-start gap-2">
                <Award className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
                <span><strong>Gunakan Layanan Pinjaman:</strong> Mengambil dan melunasi angsuran secara tepat waktu berkontribusi langsung pada pendapatan jasa usaha koperasi.</span>
              </li>
              <li className="flex items-start gap-2">
                <Award className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
                <span><strong>Gunakan Madata Mobile:</strong> Pembayaran tagihan rutin PPOB, pulsa, token listrik melalui aplikasi ikut meningkatkan pendapatan koperasi.</span>
              </li>
            </ul>
          </div>

          <div className="bg-white dark:bg-slate-800 rounded-2xl p-6 sm:p-8 border border-slate-200 dark:border-slate-700 shadow-sm relative">
<h3 className="text-xl font-bold text-black dark:text-white mb-4">
              Rapat Anggota Tahunan (RAT)
            </h3>
            <p className="text-xs sm:text-sm text-black dark:text-slate-300 leading-relaxed mb-4">
              Rapat Anggota Tahunan (RAT) merupakan kekuasaan tertinggi dalam koperasi. Setiap anggota memiliki hak suara yang setara (one man one vote) untuk:
            </p>
            <ul className="space-y-2 text-xs sm:text-sm text-black dark:text-slate-300">
              <li className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-teal-500" />
                <span>Mengesahkan Laporan Pertanggungjawaban Pengurus & Pengawas.</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-teal-500" />
                <span>Menetapkan persentase pembagian dan nominal riil SHU yang dibagikan.</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-teal-500" />
                <span>Merumuskan Rencana Kerja dan Anggaran Pendapatan & Belanja tahun berikutnya.</span>
              </li>
            </ul>
          </div>
        </div>

        {/* CTA */}
        <div className="rounded-2xl p-8 bg-gradient-to-r from-teal-800 via-teal-900 to-slate-900 text-white flex flex-col md:flex-row items-center justify-between gap-6 shadow-xl">
          <div>
            <h3 className="text-xl font-bold mb-1">Mari Bertumbuh dan Sejahtera Bersama</h3>
            <p className="text-teal-200 text-xs sm:text-sm">
              Bergabunglah menjadi anggota resmi Koperasi Mandara Sedana Kuta dan nikmati hak bagian SHU Anda setiap tahun.
            </p>
          </div>
          <Link
            href="/daftar-anggota"
            className="shrink-0 flex items-center gap-2 bg-white text-teal-900 hover:bg-teal-50 font-bold px-6 py-3 rounded-xl shadow-lg transition-all text-sm"
          >
            <span>Daftar Jadi Anggota</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      </div>
</div>
  );
}
