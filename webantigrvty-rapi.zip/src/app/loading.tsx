export default function Loading() {
  return (
    <div className="min-h-[60vh] flex flex-col items-center justify-center p-8">
      <div className="w-12 h-12 border-4 border-teal-200 dark:border-teal-900 border-t-teal-600 rounded-full animate-spin mb-4" />
      <p className="text-xs sm:text-sm font-semibold text-black dark:text-slate-400">
        Memuat halaman...
      </p>
    </div>
  );
}
