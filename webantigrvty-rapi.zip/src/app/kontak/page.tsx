import type { Metadata } from "next";
import ContactForm from "@/components/forms/ContactForm";
import Breadcrumb from "@/components/ui/Breadcrumb";
import SectionBadge from "@/components/ui/SectionBadge";

import { SITE_CONFIG, WHATSAPP_URL } from "@/lib/constants";
import { MapPin, Mail, Clock, MessageCircle, Building, ExternalLink } from "lucide-react";
export const metadata: Metadata = {
  title: "Kontak Kami | Koperasi Mandara Sedana Kuta",
  description:
    "Hubungi Koperasi Mandara Sedana Kuta. Lokasi Kantor Pusat di Legian Kuta dan Kantor Cabang di Sesetan Denpasar. Layanan WhatsApp 0813-9430-6999.",
};

export default function KontakPage() {
  return (
    <div className="min-h-screen">
      {/* Header Banner */}
      <div className="bg-gradient-to-br from-teal-800 via-teal-900 to-slate-900 py-16 px-4 text-center relative overflow-hidden">
<div className="relative z-10 max-w-4xl mx-auto">
          <SectionBadge variant="cyan">
            Layanan Pelanggan & Lokasi
          </SectionBadge>
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold text-white mb-4 tracking-tight">
            Hubungi Koperasi Kami
          </h1>
          <p className="text-teal-200 text-base md:text-lg max-w-2xl mx-auto">
            Kami siap menyambut dan mendengarkan setiap kebutuhan finansial Anda di kantor Pusat Legian, kantor Cabang Sesetan, atau secara daring melalui WhatsApp.
          </p>
        </div>
      </div>

      {/* Breadcrumb Bar */}
      <div className="bg-slate-100 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-800 py-3 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <Breadcrumb items={[{ label: "Kontak" }]} />
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto py-16 px-4 sm:px-6 lg:px-8">
        {/* Quick Contact Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          <a
            href={WHATSAPP_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="bg-white dark:bg-slate-800 p-6 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm hover:shadow-md transition-shadow group flex flex-col justify-between"
          >
            <div>
              <div className="w-12 h-12 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                <MessageCircle className="w-6 h-6" />
              </div>
              <span className="text-xs uppercase font-bold text-black">WhatsApp Resmi</span>
              <h3 className="font-bold text-black dark:text-white text-base mt-1">
                +62 813-9430-6999
              </h3>
            </div>
            <span className="text-xs text-emerald-600 dark:text-emerald-400 font-semibold mt-4 flex items-center gap-1">
              Kirim Chat <ExternalLink className="w-3 h-3" />
            </span>
          </a>

          <a
            href={`mailto:${SITE_CONFIG.email}`}
            className="bg-white dark:bg-slate-800 p-6 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm hover:shadow-md transition-shadow group flex flex-col justify-between"
          >
            <div>
              <div className="w-12 h-12 rounded-xl bg-teal-50 dark:bg-teal-950/60 text-teal-600 dark:text-teal-400 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                <Mail className="w-6 h-6" />
              </div>
              <span className="text-xs uppercase font-bold text-black">Email Korespondensi</span>
              <h3 className="font-bold text-black dark:text-white text-sm sm:text-base mt-1 truncate">
                {SITE_CONFIG.email}
              </h3>
            </div>
            <span className="text-xs text-teal-600 dark:text-teal-400 font-semibold mt-4 flex items-center gap-1">
              Kirim Email <ExternalLink className="w-3 h-3" />
            </span>
          </a>

          <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm flex flex-col justify-between">
            <div>
              <div className="w-12 h-12 rounded-xl bg-cyan-50 dark:bg-cyan-950/60 text-cyan-600 dark:text-cyan-400 flex items-center justify-center mb-4">
                <Clock className="w-6 h-6" />
              </div>
              <span className="text-xs uppercase font-bold text-black">Jam Operasional</span>
              <h3 className="font-bold text-black dark:text-white text-sm mt-1">
                Sen – Jum: 08:00 – 16:00
              </h3>
              <p className="text-xs text-black mt-0.5">Sabtu: 08:00 – 13:00 WITA</p>
            </div>
            <span className="text-xs text-black font-medium mt-4">Hari Minggu & Libur Nasional Tutup</span>
          </div>

          <div className="bg-white dark:bg-slate-800 p-6 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm flex flex-col justify-between">
            <div>
              <div className="w-12 h-12 rounded-xl bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 flex items-center justify-center mb-4">
                <svg className="w-6 h-6" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
                </svg>
              </div>
              <span className="text-xs uppercase font-bold text-black">Media Sosial</span>
              <h3 className="font-bold text-black dark:text-white text-xs sm:text-sm mt-1 truncate">
                @{SITE_CONFIG.instagram}
              </h3>
            </div>
            <div className="flex gap-2 mt-4">
              <a
                href={`https://instagram.com/${SITE_CONFIG.instagram}`}
                target="_blank"
                rel="noopener noreferrer"
                className="text-xs text-teal-600 dark:text-teal-400 font-semibold hover:underline"
              >
                Instagram
              </a>
              <span className="text-slate-300">•</span>
              <a
                href={`https://facebook.com/${SITE_CONFIG.facebook}`}
                target="_blank"
                rel="noopener noreferrer"
                className="text-xs text-teal-600 dark:text-teal-400 font-semibold hover:underline"
              >
                Facebook
              </a>
            </div>
          </div>
        </div>

        {/* Contact Form & Office Locations Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 mb-16">
          <div className="lg:col-span-7">
            <ContactForm />
          </div>

          <div className="lg:col-span-5 space-y-6">
            {/* Kantor Pusat */}
            <div className="bg-white dark:bg-slate-800 rounded-3xl p-6 border border-slate-200 dark:border-slate-700 shadow-lg relative">
              <div className="flex items-start gap-3 mb-3">
                <div className="w-9 h-9 rounded-xl bg-teal-50 dark:bg-teal-950/60 text-teal-600 dark:text-teal-400 flex items-center justify-center shrink-0">
                  <Building className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-[10px] uppercase font-bold text-teal-600 tracking-wider">Kantor Utama</span>
                  <h4 className="font-bold text-black dark:text-white text-base">
                    {SITE_CONFIG.offices.pusat.name}
                  </h4>
                </div>
              </div>
              <p className="text-xs text-black dark:text-slate-300 mb-3 flex items-start gap-2">
                <MapPin className="w-4 h-4 text-black shrink-0 mt-0.5" />
                <span>{SITE_CONFIG.offices.pusat.address}, {SITE_CONFIG.offices.pusat.city}</span>
              </p>
              <div className="rounded-2xl overflow-hidden aspect-[16/9] border border-slate-100 dark:border-slate-700">
                <iframe
                  src={SITE_CONFIG.offices.pusat.mapsUrl}
                  title="Peta Kantor Pusat Legian"
                  className="w-full h-full border-none"
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                />
              </div>
            </div>

            {/* Kantor Cabang Sesetan */}
            <div className="bg-white dark:bg-slate-800 rounded-3xl p-6 border border-slate-200 dark:border-slate-700 shadow-lg relative">
<div className="flex items-start gap-3 mb-3">
                <div className="w-9 h-9 rounded-xl bg-cyan-50 dark:bg-cyan-950/60 text-cyan-600 dark:text-cyan-400 flex items-center justify-center shrink-0">
                  <Building className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-[10px] uppercase font-bold text-cyan-600 tracking-wider">Kantor Cabang</span>
                  <h4 className="font-bold text-black dark:text-white text-base">
                    {SITE_CONFIG.offices.cabang.name}
                  </h4>
                </div>
              </div>
              <p className="text-xs text-black dark:text-slate-300 mb-3 flex items-start gap-2">
                <MapPin className="w-4 h-4 text-black shrink-0 mt-0.5" />
                <span>{SITE_CONFIG.offices.cabang.address}, {SITE_CONFIG.offices.cabang.city}</span>
              </p>
              <div className="rounded-2xl overflow-hidden aspect-[16/9] border border-slate-100 dark:border-slate-700">
                <iframe
                  src={SITE_CONFIG.offices.cabang.mapsUrl}
                  title="Peta Kantor Cabang Sesetan"
                  className="w-full h-full border-none"
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                />
              </div>
            </div>
          </div>
        </div>
      </div>

</div>
  );
}
