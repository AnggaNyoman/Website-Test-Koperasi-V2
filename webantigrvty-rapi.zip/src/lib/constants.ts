// ============================================
// SITE-WIDE CONSTANTS & CONFIGURATION
// ============================================

export const SITE_CONFIG = {
  name: "Koperasi Mandara Sedana Kuta",
  shortName: "Mandara Sedana Kuta",
  tagline: "Bersama Wujudkan Impian",
  description:
    "Koperasi Simpan Pinjam modern berbasis di Bali. Solusi keuangan terpercaya untuk anggota sejahtera dengan layanan digital melalui Madata Mobile.",
  legalitas: "No. 004723/BH/M KUKM.2/VII/2017",
  whatsapp: "6281394306999",
  whatsappText: "Halo%20Koperasi%20Mandara%20Sedanakuta",
  email: "info@mandarasedanakuta.co.id",
  instagram: "koperasimandarasedanakuta",
  facebook: "koperasimandarasedanakuta",
  googlePlayUrl:
    "https://play.google.com/store/apps/details?id=sevanam.com.madatamobileapps&pcampaignid=web_share",
  youtubeProfile: "https://youtu.be/qLutMmpkLEo",
  offices: {
    pusat: {
      name: "Kantor Pusat",
      address: "Jl. Legian Kuta Gang Bendesa No.5",
      city: "Kuta, Badung — Bali",
      mapsUrl:
        "https://www.google.com/maps?q=KSP%20Mandara%20Sedana%20Kuta%2C%20Jl.%20Legian%20Kuta%20Gang%20Bendesa%20No.5%2C%20Kuta%2C%20Badung%2C%20Bali&output=embed",
    },
    cabang: {
      name: "Kantor Cabang",
      address: "Jl. Tukad Banyu Sari No. 100, Sesetan",
      city: "Denpasar Selatan — Bali",
      mapsUrl:
        "https://www.google.com/maps?q=Koperasi%20Mandara%20Sedana%20Kuta%20Cabang%20Sesetan%2C%20Jl.%20Tukad%20Banyu%20Sari%20No.100%2C%20Sesetan%2C%20Denpasar%20Selatan%2C%20Bali&output=embed",
    },
  },
  ga4Id: "G-XXXXXXXXXX", // Replace with actual GA4 ID
};

export const WHATSAPP_URL = `https://wa.me/${SITE_CONFIG.whatsapp}?text=${SITE_CONFIG.whatsappText}`;

export const NAV_LINKS = [
  { href: "/", label: "Beranda" },
  {
    href: "/tentang-kami",
    label: "Tentang Kami",
    children: [
      { href: "/tentang-kami#visi-misi", label: "Visi & Misi" },
      { href: "/tentang-kami#nilai-keren", label: "Nilai KEREN" },
      { href: "/tentang-kami#struktur", label: "Struktur Organisasi" },
    ],
  },
  {
    href: "/layanan",
    label: "Layanan",
    children: [
      { href: "/layanan#simpanan", label: "Simpanan" },
      { href: "/layanan#pinjaman", label: "Pinjaman" },
    ],
  },
  { href: "/produk", label: "Produk" },
  { href: "/simulasi", label: "Simulasi" },
  { href: "/shu", label: "SHU" },
  { href: "/madata-mobile", label: "Madata Mobile" },
  { href: "/galeri", label: "Galeri" },
  { href: "/faq", label: "FAQ" },
  { href: "/kontak", label: "Kontak" },
];

export const STATS = [
  {
    value: 2231,
    suffix: "+",
    label: "Anggota Aktif",
    icon: "Users",
    color: "text-primary-500",
  },
  {
    value: 90,
    suffix: "M+",
    prefix: "Rp ",
    label: "Total Aset Koperasi",
    icon: "TrendingUp",
    color: "text-cyan-500",
  },
  {
    value: 2017,
    suffix: "",
    label: "Tahun Berdiri",
    icon: "Calendar",
    color: "text-gold",
  },
  {
    value: 2,
    suffix: "",
    label: "Kantor Cabang",
    icon: "MapPin",
    color: "text-primary-500",
  },
];

export const VIDEOS = [
  {
    id: "v1",
    title: "Company Profile Koperasi Mandara Sedana Kuta",
    category: "Profil",
    videoId: "qLutMmpkLEo",
    thumbnail: "https://img.youtube.com/vi/qLutMmpkLEo/maxresdefault.jpg",
    url: "https://youtu.be/qLutMmpkLEo",
    description: "Kenali lebih dekat Koperasi Mandara Sedana Kuta dan layanan unggulan kami.",
  },
  {
    id: "v2",
    title: "Madata Community — Bersama Lebih Kuat",
    category: "Komunitas",
    videoId: "8iTTaLASq2Q",
    thumbnail: "https://img.youtube.com/vi/8iTTaLASq2Q/maxresdefault.jpg",
    url: "https://youtu.be/8iTTaLASq2Q",
    description: "Kegiatan komunitas dan gotong royong anggota Mandara Sedana Kuta.",
  },
  {
    id: "v3",
    title: "Madata Podcast — Wawasan Keuangan",
    category: "Podcast",
    videoId: "4ewvB-QrRMY",
    thumbnail: "https://img.youtube.com/vi/4ewvB-QrRMY/maxresdefault.jpg",
    url: "https://youtu.be/4ewvB-QrRMY",
    description: "Diskusi mendalam seputar literasi keuangan dan pengembangan usaha anggota.",
  },
  {
    id: "v4",
    title: "Solidaritas Madata — Peduli Sesama",
    category: "Sosial",
    videoId: "bozMSASoYjY",
    thumbnail: "https://img.youtube.com/vi/bozMSASoYjY/maxresdefault.jpg",
    url: "https://youtu.be/bozMSASoYjY",
    description: "Kegiatan sosial dan bakti masyarakat bersama Koperasi Mandara Sedana Kuta.",
  },
  {
    id: "v5",
    title: "Madata Community — Kebersamaan Anggota",
    category: "Komunitas",
    videoId: "VCwF0PuNzlo",
    thumbnail: "https://img.youtube.com/vi/VCwF0PuNzlo/maxresdefault.jpg",
    url: "https://youtu.be/VCwF0PuNzlo",
    description: "Momen kebersamaan dan kekeluargaan anggota Madata Community.",
  },
  {
    id: "v6",
    title: "Madata Community — Gotong Royong",
    category: "Komunitas",
    videoId: "WeJucv95Plg",
    thumbnail: "https://img.youtube.com/vi/WeJucv95Plg/maxresdefault.jpg",
    url: "https://youtu.be/WeJucv95Plg",
    description: "Semangat gotong royong dalam setiap kegiatan komunitas Madata.",
  },
  {
    id: "v7",
    title: "Madata Community — Silaturahmi Anggota",
    category: "Komunitas",
    videoId: "Ig4_VQ2Dopc",
    thumbnail: "https://img.youtube.com/vi/Ig4_VQ2Dopc/maxresdefault.jpg",
    url: "https://youtu.be/Ig4_VQ2Dopc",
    description: "Mempererat silaturahmi antar anggota Koperasi Mandara Sedana Kuta.",
  },
  {
    id: "v8",
    title: "Madata Community — Kegiatan Bersama",
    category: "Komunitas",
    videoId: "cGLsiMFDMQ0",
    thumbnail: "https://img.youtube.com/vi/cGLsiMFDMQ0/maxresdefault.jpg",
    url: "https://youtu.be/cGLsiMFDMQ0",
    description: "Dokumentasi kegiatan bersama komunitas Madata di Bali.",
  },
  {
    id: "v9",
    title: "Madata Community — Semangat Kolaborasi",
    category: "Komunitas",
    videoId: "RBE9t6sC4WM",
    thumbnail: "https://img.youtube.com/vi/RBE9t6sC4WM/maxresdefault.jpg",
    url: "https://youtu.be/RBE9t6sC4WM",
    description: "Kolaborasi dan sinergi anggota dalam ekosistem koperasi.",
  },
  {
    id: "v10",
    title: "Madata Podcast — Edisi 2",
    category: "Podcast",
    videoId: "xeXlnnKA9h0",
    thumbnail: "https://img.youtube.com/vi/xeXlnnKA9h0/maxresdefault.jpg",
    url: "https://youtu.be/xeXlnnKA9h0",
    description: "Obrolan santai seputar literasi keuangan dan koperasi.",
  },
  {
    id: "v11",
    title: "Madata Podcast — Edisi 3",
    category: "Podcast",
    videoId: "MWAaUEN-Q_U",
    thumbnail: "https://img.youtube.com/vi/MWAaUEN-Q_U/maxresdefault.jpg",
    url: "https://youtu.be/MWAaUEN-Q_U",
    description: "Diskusi mendalam seputar pengembangan usaha anggota.",
  },
  {
    id: "v12",
    title: "Madata Podcast — Edisi 4",
    category: "Podcast",
    videoId: "_f00S8DFEEg",
    thumbnail: "https://img.youtube.com/vi/_f00S8DFEEg/maxresdefault.jpg",
    url: "https://youtu.be/_f00S8DFEEg",
    description: "Wawasan keuangan dan tips mengelola simpanan bersama Madata.",
  },
  {
    id: "v13",
    title: "Madata Podcast — Edisi 5",
    category: "Podcast",
    videoId: "SmadUIfRCw4",
    thumbnail: "https://img.youtube.com/vi/SmadUIfRCw4/maxresdefault.jpg",
    url: "https://youtu.be/SmadUIfRCw4",
    description: "Perbincangan seputar dunia koperasi dan keuangan mikro.",
  },
  {
    id: "v14",
    title: "Madata Podcast — Edisi 6",
    category: "Podcast",
    videoId: "9lM3dDRpHFA",
    thumbnail: "https://img.youtube.com/vi/9lM3dDRpHFA/maxresdefault.jpg",
    url: "https://youtu.be/9lM3dDRpHFA",
    description: "Diskusi bersama narasumber seputar literasi keuangan anggota.",
  },
  {
    id: "v15",
    title: "Madata Podcast — Edisi 7",
    category: "Podcast",
    videoId: "RTk82Mh3thk",
    thumbnail: "https://img.youtube.com/vi/RTk82Mh3thk/maxresdefault.jpg",
    url: "https://youtu.be/RTk82Mh3thk",
    description: "Wawasan dan inspirasi seputar pertumbuhan usaha anggota koperasi.",
  },
  {
    id: "v16",
    title: "Solidaritas Madata — Bakti Sosial",
    category: "Sosial",
    videoId: "940chlI6sjY",
    thumbnail: "https://img.youtube.com/vi/940chlI6sjY/maxresdefault.jpg",
    url: "https://youtu.be/940chlI6sjY",
    description: "Kegiatan bakti sosial Koperasi Mandara Sedana Kuta bagi masyarakat.",
  },
  {
    id: "v17",
    title: "Solidaritas Madata — Kepedulian Anggota",
    category: "Sosial",
    videoId: "8yjPHKYQcWM",
    thumbnail: "https://img.youtube.com/vi/8yjPHKYQcWM/maxresdefault.jpg",
    url: "https://youtu.be/8yjPHKYQcWM",
    description: "Wujud kepedulian dan solidaritas anggota terhadap sesama.",
  },
];

export const KEREN_VALUES = [
  {
    letter: "K",
    title: "Kolaborasi",
    color: "#065A74",
    textColor: "text-white",
    bgGradient: "from-teal-800 to-teal-700",
    description:
      "Bersinergi dengan stakeholder, mitra, dan lintas unit dengan semangat gotong royong untuk membangun ekosistem koperasi yang terintegrasi, memperluas jaringan, serta mendorong pertumbuhan usaha anggota secara berkelanjutan.",
  },
  {
    letter: "E",
    title: "Etika",
    color: "#0ABCF0",
    textColor: "text-white",
    bgGradient: "from-cyan-600 to-cyan-500",
    description:
      "Menjaga integritas, kejujuran, transparansi, komitmen dan tanggung jawab dalam setiap tindakan.",
  },
  {
    letter: "R",
    title: "Responsif",
    color: "#10B981",
    textColor: "text-white",
    bgGradient: "from-emerald-600 to-emerald-500",
    description:
      "Tanggap terhadap kebutuhan anggota dan perubahan lingkungan usaha.",
  },
  {
    letter: "E",
    title: "Empati",
    color: "#F97316",
    textColor: "text-white",
    bgGradient: "from-orange-600 to-orange-500",
    description:
      "Memahami dan peduli terhadap kesejahteraan anggota, rekan kerja, alam dan lingkungan sekitar.",
  },
  {
    letter: "N",
    title: "Niat Bertumbuh",
    color: "#F59E0B",
    textColor: "text-white",
    bgGradient: "from-amber-600 to-amber-500",
    description:
      "Selalu belajar, tumbuh, dan berinovasi dengan semangat memperbaiki diri dan organisasi, seraya bersyukur atas setiap proses yang dijalani.",
  },
];

export const SERVICES = [
  {
    id: "simpanan-pokok",
    title: "Simpanan Pokok",
    description:
      "Simpanan awal saat mendaftar sebagai anggota sebesar Rp 10.000. Bersifat modal sendiri dan tidak dapat ditarik selama menjadi anggota.",
    icon: "Wallet",
    category: "simpanan",
    color: "from-teal-600 to-teal-800",
  },
  {
    id: "simpanan-wajib",
    title: "Simpanan Wajib",
    description:
      "Setoran rutin Rp 10.000/bulan sebagai modal sendiri anggota. Dapat ditarik saat berhenti menjadi anggota.",
    icon: "PiggyBank",
    category: "simpanan",
    color: "from-cyan-600 to-teal-700",
  },
  {
    id: "sirela",
    title: "SIRELA (Simpanan Sukarela)",
    description:
      "Tabungan bebas setoran dan penarikan kapan saja. Setoran awal minimum Rp 10.000 dengan bunga 2% per tahun.",
    icon: "Coins",
    category: "simpanan",
    color: "from-primary-600 to-cyan-600",
  },
  {
    id: "sijaka",
    title: "SIJAKA (Simpanan Berjangka)",
    description:
      "Deposito dengan tenor 3, 6, atau 12 bulan. Bunga kompetitif 3,8%-6,2% per tahun dengan minimum penempatan Rp 5.000.000.",
    icon: "Clock",
    category: "simpanan",
    color: "from-teal-700 to-cyan-500",
  },
  {
    id: "pinjaman-usaha",
    title: "Pinjaman Usaha",
    description:
      "Pembiayaan untuk pengembangan bisnis anggota dengan agunan. Bunga 1,2%-1,5% per bulan, tenor fleksibel 1-5 tahun.",
    icon: "Briefcase",
    category: "pinjaman",
    color: "from-primary-600 to-primary-800",
  },
  {
    id: "pinjaro",
    title: "PINJARO (Pinjaman Harian Mikro)",
    description:
      "Pinjaman tanpa agunan untuk pelaku usaha mikro. Plafon Rp 500 ribu - Rp 5 juta, tenor 100 hari, bunga 0,09% per hari.",
    icon: "Zap",
    category: "pinjaman",
    color: "from-cyan-600 to-primary-600",
  },
  {
    id: "pinjaman-kpr",
    title: "Pinjaman KPR/Tanah",
    description:
      "Pembiayaan untuk membeli rumah atau tanah dengan agunan SHM. Bunga 1,2%-1,5% per bulan, tenor hingga 10 tahun.",
    icon: "GraduationCap",
    category: "pinjaman",
    color: "from-teal-600 to-primary-600",
  },
  {
    id: "pinjaman-motor",
    title: "Pinjaman Sepeda Motor",
    description:
      "Pembiayaan pembelian sepeda motor baru maupun bekas dengan agunan kendaraan yang dibeli. Bunga 1,3% per bulan, tenor 1-2 tahun.",
    icon: "CreditCard",
    category: "pinjaman",
    color: "from-primary-500 to-teal-700",
  },
];

export const SIMPANAN_PRODUCTS = [
  {
    jenis: "SIRELA (Simpanan Sukarela)",
    setoran: "Awal Rp10.000, selanjutnya min. Rp5.000",
    bunga: "2%/tahun",
    keterangan: "Setor & tarik bebas kapan saja. Saldo minimal Rp10.000.",
    highlight: true,
  },
  {
    jenis: "SIJAKA (Simpanan Berjangka)",
    setoran: "Min. Rp5.000.000",
    bunga: "3,8% – 6,2%/tahun",
    keterangan: "Jangka waktu 3, 6, atau 12 bulan. Dapat dijadikan agunan pinjaman.",
    highlight: false,
  },
  {
    jenis: "SIRENA (Simpanan Berencana)",
    setoran: "Min. Rp25.000/bulan",
    bunga: "4,37% – 4,79%/tahun",
    keterangan: "Setoran rutin bulanan, jangka waktu minimal 1 tahun (bunga makin besar untuk tenor lebih panjang, hingga 10 tahun).",
    highlight: true,
  },
  {
    jenis: "SIRENA PLUS",
    setoran: "Min. Rp5.000.000 (sekali di awal)",
    bunga: "7,80% – 8,47%/tahun",
    keterangan: "Penempatan sekali di awal, jangka waktu minimal 5 tahun.",
    highlight: false,
  },
  {
    jenis: "SIMPEL (Simpanan Pelajar)",
    setoran: "Awal Rp10.000, selanjutnya min. Rp5.000",
    bunga: "2%/tahun",
    keterangan: "Khusus pelajar, dibuka melalui kerja sama dengan pihak sekolah.",
    highlight: false,
  },
  {
    jenis: "SIKELUNG (Simpanan Ketekan Galungan)",
    setoran: "Setoran harian sesuai nominal awal (min. Rp5.000)",
    bunga: "—",
    keterangan: "Jangka waktu 200 hari, tanpa bunga, mendapat bingkisan di akhir periode.",
    highlight: false,
  },
];

export const PINJAMAN_PRODUCTS = [
  {
    jenis: "PINJARO (Pinjaman Harian Mikro)",
    plafon: "Rp500.000 – Rp5.000.000",
    bunga: "0,09%/hari",
    tenor: "100 hari",
    highlight: true,
  },
  {
    jenis: "Pinjaman Usaha",
    plafon: "Sesuai pengajuan & nilai agunan",
    bunga: "1,2% – 1,5%/bulan",
    tenor: "1 – 5 tahun",
    highlight: true,
  },
  {
    jenis: "Pinjaman Modal Koperasi",
    plafon: "Rp5.000.000 / Rp10.000.000",
    bunga: "Tanpa bunga",
    tenor: "50 bulan",
    highlight: false,
  },
  {
    jenis: "Pinjaman KPR / Tanah",
    plafon: "Sesuai pengajuan & nilai agunan",
    bunga: "1,2% – 1,5%/bulan",
    tenor: "1 – 10 tahun",
    highlight: false,
  },
  {
    jenis: "Pinjaman Renovasi",
    plafon: "Sesuai pengajuan & nilai agunan",
    bunga: "1,2% – 1,5%/bulan",
    tenor: "1 – 5 tahun",
    highlight: false,
  },
  {
    jenis: "Pinjaman Investasi",
    plafon: "Sesuai pengajuan & nilai agunan",
    bunga: "1,2% – 1,5%/bulan",
    tenor: "1 – 10 tahun",
    highlight: false,
  },
  {
    jenis: "Pinjaman Sepeda Motor",
    plafon: "Sesuai pengajuan & nilai agunan",
    bunga: "1,3%/bulan",
    tenor: "1 – 2 tahun",
    highlight: false,
  },
  {
    jenis: "Pinjaman Mobil",
    plafon: "Sesuai pengajuan & nilai agunan",
    bunga: "1,2% – 1,5%/bulan",
    tenor: "1 – 5 tahun",
    highlight: false,
  },
  {
    jenis: "Pinjaman Yadnya",
    plafon: "Sesuai pengajuan & nilai agunan",
    bunga: "1%/bulan",
    tenor: "1 – 5 tahun",
    highlight: false,
  },
  {
    jenis: "Pinjaman Multiguna",
    plafon: "Sesuai pengajuan & nilai agunan",
    bunga: "1,2% – 1,5%/bulan",
    tenor: "1 – 5 tahun",
    highlight: false,
  },
  {
    jenis: "Pinjaman Back to Back",
    plafon: "Maks. 90% dari nilai agunan (SIRELA/SIJAKA)",
    bunga: "1,5%/bulan + bunga simpanan",
    tenor: "1 – 5 tahun",
    highlight: false,
  },
  {
    jenis: "Pinjaman Sinergi",
    plafon: "Maks. Rp10.000.000 tanpa agunan",
    bunga: "1,2%/bulan",
    tenor: "1 – 5 tahun",
    highlight: false,
  },
];

export const TESTIMONIALS = [
  {
    id: "t1",
    name: "I Wayan Sudiarta",
    role: "Pedagang Pasar — Anggota sejak 2018",
    content:
      "Berkat pinjaman modal usaha dari Koperasi Mandara Sedana Kuta, warung saya berkembang pesat. Prosesnya mudah dan tidak ribet. Tim koperasi juga sangat membantu dan ramah!",
    rating: 5,
    location: "Badung, Bali",
  },
  {
    id: "t2",
    name: "Ni Luh Putu Arisani",
    role: "Pengusaha Kerajinan — Anggota sejak 2019",
    content:
      "Madata Mobile sangat memudahkan saya cek saldo dan bayar tagihan. Tidak perlu antri di kantor lagi. Fitur lengkap dan mudah digunakan, bahkan oleh orang tua sekalipun.",
    rating: 5,
    location: "Denpasar, Bali",
  },
  {
    id: "t3",
    name: "Kadek Wirawan",
    role: "Petani — Anggota sejak 2020",
    content:
      "Simpanan berjangka saya menghasilkan bunga yang lumayan. Uang saya aman dan berkembang. Koperasi ini benar-benar membantu perekonomian keluarga kami di Bali.",
    rating: 5,
    location: "Gianyar, Bali",
  },
  {
    id: "t4",
    name: "Made Sutrisna",
    role: "Guru Honorer — Anggota sejak 2021",
    content:
      "Pinjaman pendidikan sangat membantu biaya kuliah anak saya. Bunga ringan dan cicilan terjangkau. Terima kasih Koperasi Mandara Sedana Kuta sudah membantu impian keluarga kami!",
    rating: 5,
    location: "Tabanan, Bali",
  },
  {
    id: "t5",
    name: "Ni Made Dwi Astuti",
    role: "Ibu Rumah Tangga — Anggota sejak 2022",
    content:
      "Saya suka banget dengan layanan simpanan sukarelanya. Bisa setor dan tarik kapan saja. Pelayanan Koperasi Mandara Sedana Kuta selalu ramah dan profesional.",
    rating: 5,
    location: "Klungkung, Bali",
  },
];

export const FAQ_DATA = [
  {
    id: "faq1",
    category: "Anggota",
    question: "Apa saja syarat untuk menjadi anggota Koperasi Mandara Sedana Kuta?",
    answer:
      "Syarat menjadi anggota: (1) WNI dengan KTP yang masih berlaku, (2) Kartu Keluarga (KK), (3) Berdomisili di Provinsi Bali, (4) Usia minimal 17 tahun atau sudah menikah, (5) Mengisi formulir pendaftaran, (6) Menyetujui AD/ART koperasi, dan (7) Membayar Simpanan Pokok Rp 10.000 & Simpanan Wajib Rp 10.000.",
  },
  {
    id: "faq2",
    category: "Anggota",
    question: "Bagaimana proses pendaftaran anggota baru?",
    answer:
      "Anda dapat mendaftar secara online melalui formulir di website ini, lalu tim kami akan menghubungi Anda via WhatsApp dalam 1x24 jam. Untuk menyelesaikan pendaftaran, Anda perlu datang ke kantor kami (Pusat di Legian atau Cabang di Sesetan) dengan membawa KTP dan KK asli.",
  },
  {
    id: "faq3",
    category: "Simpanan",
    question: "Berapa bunga simpanan berjangka yang ditawarkan?",
    answer:
      "Bunga SIJAKA (Simpanan Berjangka): 3,8%/tahun untuk tenor 3 bulan, 5%/tahun untuk tenor 6 bulan, dan 6,2%/tahun untuk tenor 12 bulan. Minimum penempatan Rp 5.000.000. Bunga dapat berubah sesuai kebijakan dan hasil Rapat Anggota.",
  },
  {
    id: "faq4",
    category: "Simpanan",
    question: "Apakah simpanan saya aman?",
    answer:
      "Ya, simpanan anggota aman karena: (1) Koperasi diawasi oleh Dinas Koperasi Provinsi Bali dan Kemenkop UKM RI, (2) Koperasi memiliki badan hukum resmi No. 004723/BH/M KUKM.2/VII/2017, dan (3) Dana dikelola secara profesional dengan tata kelola yang transparan.",
  },
  {
    id: "faq5",
    category: "Pinjaman",
    question: "Berapa maksimal pinjaman yang bisa saya ajukan?",
    answer:
      "Plafon pinjaman tergantung jenis: PINJARO (pinjaman harian mikro) Rp500 ribu - Rp5 juta tanpa agunan, sedangkan pinjaman lain (Usaha, KPR/Tanah, Renovasi, Investasi, Mobil, dll) plafonnya fleksibel sesuai pengajuan dan nilai agunan, maksimal sebesar BMPP (Batas Maksimum Pemberian Pinjaman). Besaran pinjaman disetujui berdasarkan kemampuan bayar dan riwayat simpanan anggota.",
  },
  {
    id: "faq6",
    category: "Pinjaman",
    question: "Apa saja biaya yang dikenakan saat mengajukan pinjaman?",
    answer:
      "Biaya pinjaman (untuk pinjaman beragunan seperti Usaha, KPR/Tanah, Renovasi, dll) meliputi: Biaya Administrasi 1% (tenor 1-2 tahun), 1,5% (3-4 tahun), atau 2% (5 tahun ke atas) dari plafon; Provisi 0,5% dari plafon; serta biaya materai, asuransi, dan notaris sesuai penggunaan/tagihan. PINJARO (pinjaman harian mikro) hanya dikenakan biaya materai Rp10.000 tanpa provisi.",
  },
  {
    id: "faq7",
    category: "Pinjaman",
    question: "Bagaimana cara mengajukan pinjaman?",
    answer:
      "Pengajuan pinjaman bisa dilakukan dengan: (1) Datang langsung ke kantor Pusat (Legian) atau Cabang (Sesetan), (2) Menghubungi kami via WhatsApp di +62 813-9430-6999, atau (3) Menggunakan fitur simulasi di website untuk memperkirakan cicilan terlebih dahulu.",
  },
  {
    id: "faq8",
    category: "Madata Mobile",
    question: "Apa itu Madata Mobile dan bagaimana cara mengunduhnya?",
    answer:
      "Madata Mobile adalah aplikasi perbankan digital Koperasi Mandara Sedana Kuta yang memungkinkan anggota mengakses layanan keuangan kapan saja dan di mana saja. Unduh di Google Play Store dengan kata kunci 'Madata Mobile' atau scan QR code yang tersedia di website kami.",
  },
  {
    id: "faq9",
    category: "Madata Mobile",
    question: "Fitur apa saja yang tersedia di Madata Mobile?",
    answer:
      "Madata Mobile menyediakan: Cek Saldo & Mutasi Rekening, Pembelian Pulsa & Paket Data, Pembelian Token Listrik, Top Up OVO & GoPay, Pembayaran BPJS Kesehatan & PDAM, dan Login Biometrik (sidik jari/wajah) untuk keamanan ekstra.",
  },
  {
    id: "faq10",
    category: "SHU",
    question: "Apa itu SHU dan kapan dibagikan?",
    answer:
      "SHU (Sisa Hasil Usaha) adalah keuntungan bersih koperasi yang dibagikan kepada anggota setiap tahun, dibagikan setelah Rapat Anggota Tahunan (RAT) untuk tahun buku sebelumnya. Pembagian: 40% berdasarkan simpanan, 40% berdasarkan transaksi, dan 20% untuk cadangan koperasi.",
  },
  {
    id: "faq11",
    category: "SHU",
    question: "Bagaimana cara menghitung SHU yang saya terima?",
    answer:
      "SHU yang diterima anggota dihitung berdasarkan proporsi simpanan dan transaksi anggota terhadap total koperasi. Semakin besar simpanan dan transaksi Anda, semakin besar SHU yang Anda terima. Detail perhitungan disampaikan dalam Rapat Anggota Tahunan (RAT).",
  },
  {
    id: "faq12",
    category: "Umum",
    question: "Di mana saja kantor Koperasi Mandara Sedana Kuta?",
    answer:
      "Koperasi Mandara Sedana Kuta memiliki 2 kantor: (1) Kantor Pusat di Jl. Legian Kuta Gang Bendesa No.5, Kuta, Badung, Bali. (2) Kantor Cabang di Jl. Tukad Banyu Sari No. 100, Sesetan, Denpasar Selatan, Bali. Hubungi kami via WhatsApp +62 813-9430-6999 untuk informasi jam operasional.",
  },
];

export const HISTORY_TIMELINE = [
  {
    year: "2017",
    title: "Berdirinya Koperasi",
    description:
      "Koperasi Mandara Sedana Kuta resmi berdiri dengan Badan Hukum No. 004723/BH/M KUKM.2/VII/2017 yang ditetapkan oleh Kemenkop UKM RI pada bulan Juli.",
    icon: "Star",
  },
  {
    year: "2017",
    title: "Pembukaan Kantor Pusat",
    description:
      "Kantor Pusat resmi dibuka di Jl. Legian Kuta Gang Bendesa No.5, Kuta, mulai melayani anggota dengan produk simpanan dan pinjaman.",
    icon: "Building",
  },
  {
    year: "2017",
    title: "Peluncuran Madata Mobile",
    description:
      "Aplikasi Madata Mobile diluncurkan, membawa layanan koperasi ke genggaman anggota sejak awal berdirinya koperasi.",
    icon: "Smartphone",
  },
  {
    year: "2026",
    title: "Pembukaan Kantor Cabang Sesetan",
    description:
      "Kantor Cabang Sesetan resmi dibuka di Jl. Tukad Banyu Sari No. 100, Denpasar Selatan, memperluas jangkauan layanan koperasi.",
    icon: "MapPin",
  },
  {
    year: "Dan Seterusnya",
    title: "Terus Berkembang Bersama Anggota",
    description:
      "Koperasi Mandara Sedana Kuta terus bertumbuh dan berinovasi bersama seluruh anggota, berkomitmen mewujudkan kesejahteraan bersama selamanya.",
    icon: "Rocket",
  },
];

export const MADATA_FEATURES = [
  {
    icon: "Wallet",
    title: "Cek Saldo & Mutasi",
    description: "Pantau saldo simpanan dan riwayat transaksi Anda real-time kapan saja.",
  },
  {
    icon: "Phone",
    title: "Beli Pulsa & Paket Data",
    description: "Isi ulang pulsa dan paket internet semua operator dengan mudah.",
  },
  {
    icon: "Zap",
    title: "Token Listrik PLN",
    description: "Beli token listrik prabayar langsung dari aplikasi, 24 jam sehari.",
  },
  {
    icon: "ArrowUpRight",
    title: "Top Up OVO & GoPay",
    description: "Isi saldo dompet digital OVO dan GoPay dengan satu ketukan.",
  },
  {
    icon: "Shield",
    title: "Bayar BPJS & PDAM",
    description: "Bayar iuran BPJS Kesehatan dan tagihan air PDAM tanpa antri.",
  },
  {
    icon: "Fingerprint",
    title: "Login Biometrik",
    description: "Keamanan ekstra dengan autentikasi sidik jari atau pengenalan wajah.",
  },
];

export const KABUPATEN_BALI = [
  "Badung",
  "Denpasar",
  "Gianyar",
  "Tabanan",
  "Klungkung",
  "Bangli",
  "Karangasem",
  "Buleleng",
  "Jembrana",
];

export const SHU_DATA = {
  persentase: 8,
  distribusi: [
    { name: "Berdasarkan Simpanan", value: 40, color: "#0ABCF0" },
    { name: "Berdasarkan Transaksi", value: 40, color: "#3FDA40" },
    { name: "Cadangan Koperasi", value: 20, color: "#D4AF37" },
  ],
  dibagikan: "Januari",
  tahunBuku: "Tahun Buku Sebelumnya",
};

export const HERO_SLIDES = [
  {
    id: 1,
    title: "Bersama Wujudkan Impian",
    subtitle: "Koperasi Modern untuk Anggota Sejahtera",
    description:
      "Koperasi Simpan Pinjam terpercaya di Bali dengan layanan digital terdepan. Bergabunglah bersama lebih dari 2.231 anggota aktif dan terus bertambah.",
    cta: "Gabung Sekarang",
    ctaHref: "/daftar-anggota",
    ctaSecondary: "Simulasi Pinjaman",
    ctaSecondaryHref: "/simulasi",
    gradient: "from-teal-800 via-teal-700 to-cyan-700",
    badge: "Koperasi Terpercaya Bali",
  },
  {
    id: 2,
    title: "Madata Mobile — Koperasi di Genggaman Anda",
    subtitle: "Layanan Digital 24/7 Tanpa Batas",
    description:
      "Cek saldo, bayar tagihan, beli pulsa, dan top up dompet digital langsung dari smartphone Anda. Download sekarang!",
    cta: "Download Sekarang",
    ctaHref:
      "https://play.google.com/store/apps/details?id=sevanam.com.madatamobileapps&pcampaignid=web_share",
    ctaSecondary: "Lihat Fitur",
    ctaSecondaryHref: "/madata-mobile",
    gradient: "from-cyan-700 via-teal-600 to-primary-700",
    badge: "Tersedia di Google Play",
  },
  {
    id: 3,
    title: "SHU 8% Per Tahun",
    subtitle: "Uang Anda Bekerja untuk Anda",
    description:
      "Nikmati Sisa Hasil Usaha kompetitif setiap tahun. Semakin aktif bertransaksi, semakin besar keuntungan yang Anda dapatkan.",
    cta: "Pelajari SHU",
    ctaHref: "/shu",
    ctaSecondary: "Simulasi Simpanan",
    ctaSecondaryHref: "/simulasi#simpanan",
    gradient: "from-primary-700 via-teal-700 to-teal-800",
    badge: "SHU 8%/Tahun",
  },
];

export const MEMBER_TIERS = [
  {
    id: "reguler",
    name: "Reguler",
    threshold: "Simpanan Pokok Rp10.000 + Simpanan Wajib Rp10.000/bulan",
    color: "from-slate-500 to-slate-700",
    benefits: [
      "Mendapatkan pelayanan simpanan pada koperasi",
      "Jika meninggal dunia: pengembalian simpanan setelah dikurangi biaya administrasi penutupan",
    ],
  },
  {
    id: "blue",
    name: "Blue",
    threshold: "Total Simpanan Anggota Rp260.000 – < Rp5.000.000",
    color: "from-blue-500 to-blue-700",
    benefits: [
      "Pelayanan simpanan dan pinjaman sesuai ketentuan koperasi",
      "Santunan duka Rp500.000 & kain kafan jika meninggal dunia",
      "Santunan keaktifan anggota Rp500.000 (bagi Anggota Aktif)",
    ],
  },
  {
    id: "silver",
    name: "Silver",
    threshold: "Total Simpanan Anggota Rp5.000.000 – < Rp10.000.000",
    color: "from-slate-400 to-slate-600",
    benefits: [
      "Didaftarkan BPJS Ketenagakerjaan BPU (JKK & JK)",
      "Pinjaman tanpa agunan maksimal Rp5.000.000 dengan bunga khusus",
      "Santunan duka Rp1.000.000 + kain kafan + santunan BPJS/Daperma",
    ],
  },
  {
    id: "gold",
    name: "Gold",
    threshold: "Total Simpanan Anggota Rp10.000.000 – < Rp20.000.000",
    color: "from-amber-500 to-amber-700",
    benefits: [
      "Didaftarkan BPJS Ketenagakerjaan BPU (JKK, JK & JHT)",
      "Pinjaman tanpa agunan maksimal Rp10.000.000 dengan bunga khusus",
      "Santunan duka Rp1.000.000 + karangan bunga + kain kafan + BPJS/Daperma",
    ],
  },
  {
    id: "platinum",
    name: "Platinum",
    threshold: "Total Simpanan Anggota Rp20.000.000 ke atas",
    color: "from-slate-700 to-slate-900",
    benefits: [
      "Didaftarkan BPJS Ketenagakerjaan BPU (JKK, JK & JHT)",
      "Pinjaman tanpa agunan maksimal Rp20.000.000 dengan bunga khusus",
      "Santunan duka Rp1.000.000 + karangan bunga + kain kafan + Daperma hingga Rp40.000.000",
    ],
  },
];

export const PPOB_SERVICES = [
  { title: "Simpan Pinjam", icon: "Wallet" },
  { title: "Pembayaran Listrik (PLN)", icon: "Zap" },
  { title: "Penjualan Pulsa Semua Operator", icon: "Smartphone" },
  { title: "Pembayaran PDAM", icon: "Droplet" },
  { title: "Top Up E-Money", icon: "CreditCard" },
  { title: "Transfer Dana", icon: "ArrowLeftRight" },
  { title: "Pembayaran Telepon", icon: "Phone" },
  { title: "Pembayaran BPJS Kesehatan", icon: "HeartPulse" },
];
